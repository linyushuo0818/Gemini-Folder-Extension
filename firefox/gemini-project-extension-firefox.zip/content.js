var jt=Object.defineProperty;var Rt=(n,e,t)=>e in n?jt(n,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):n[e]=t;var E=(n,e,t)=>Rt(n,typeof e!="symbol"?e+"":e,t);const Ve="gemini-projects-host",We="gemini-projects-overlay",Ze=["Gem","Gems"],Ke=["Chat","Chats"],Ye=["宝石","我的 Gem","我的 Gems"],Qe=["聊天","聊天记录","对话"];function se(n){return(n||"").trim().toLowerCase()}function Xe(n,e){const t=se(n);return e.some(o=>t.includes(se(o)))}function Je(n){return se(n).startsWith("zh")}function Bt(){var t;const n=((t=document.documentElement)==null?void 0:t.lang)||"";return Je(n)||[navigator.language||"",...navigator.languages||[]].some(o=>Je(o))?"zh":"en"}function qe(){return Bt()==="zh"?{gemsPrimary:Ye,chatsPrimary:Qe,gemsFallback:Ze,chatsFallback:Ke}:{gemsPrimary:Ze,chatsPrimary:Ke,gemsFallback:Ye,chatsFallback:Qe}}function et(n,e){const t=new Set,o=[];for(const r of[...n,...e]){const i=se(r);t.has(i)||(t.add(i),o.push(r))}return o}function mt(){const n=Array.from(document.querySelectorAll('nav, aside, [role="navigation"], [role="complementary"]')),e=qe(),t=et(e.gemsPrimary,e.gemsFallback),o=et(e.chatsPrimary,e.chatsFallback);for(const r of n){const i=r.textContent||"";if(Xe(i,t)&&Xe(i,o))return r}return null}function we(n,e){const t=e.map(r=>se(r)),o=n.querySelectorAll("div, span, h2, h3, h4, button, p");for(const r of o){const i=se(r.textContent);if(t.includes(i))return r}return null}function Dt(n){const e=qe();return we(n,e.gemsPrimary)||we(n,e.gemsFallback)}function bt(n){const e=qe();return we(n,e.chatsPrimary)||we(n,e.chatsFallback)}function $t(n){if(!n)return null;let e=n.nextElementSibling;for(;e;){if(e.querySelector("a[href]"))return e;e=e.nextElementSibling}return n.parentElement}function Nt(){let n=document.getElementById(We);if(!n){n=document.createElement("div"),n.id=We,n.style.all="initial",document.documentElement.appendChild(n);const t=n.attachShadow({mode:"open"});t.innerHTML=`
      <style>
        :host { all: initial; }
        .gp-overlay {
          position: fixed;
          inset: 0;
          pointer-events: none;
          z-index: 2147483646;
          font-family: inherit;
        }
        .gp-layer {
          position: absolute;
          inset: 0;
        }
      </style>
      <div class="gp-overlay">
        <div class="gp-layer" id="gp-overlay-layer"></div>
      </div>
    `}const e=n.shadowRoot;return{host:n,shadow:e}}function Ot(n,e,t){let o=document.getElementById(Ve);const r=t??null,i=(t==null?void 0:t.parentElement)||n;o?(o.parentElement!==i||r&&o.nextElementSibling!==r)&&i.insertBefore(o,r):(o=document.createElement("div"),o.id=Ve,o.style.all="initial",i.insertBefore(o,r));const a=o.shadowRoot??o.attachShadow({mode:"open"});a.innerHTML||(a.innerHTML=`
      <style>
        :host { all: initial; }
        .gp-panel { font-family: inherit; }
      </style>
      <div class="gp-panel" id="gp-panel-root"></div>
    `);const s=Nt();return{host:o,shadow:a,overlayShadow:s.shadow}}function qt(n){const e=n.split("/").filter(Boolean),t=e.indexOf("app");return t>=0&&e.length>t+1?e[t+1]:null}function q(n){var r,i;if(!n)return null;if(typeof n=="string")try{const a=new URL(n,window.location.origin);return qt(a.pathname)||a.searchParams.get("conversationId")||a.searchParams.get("conversation_id")||a.searchParams.get("id")||a.searchParams.get("cid")||(a.hash?a.hash.replace("#",""):null)}catch{return null}const e=n,t=((r=e.dataset)==null?void 0:r.conversationId)||((i=e.dataset)==null?void 0:i.id);if(t)return t;if(e instanceof HTMLAnchorElement&&e.href)return q(e.href);const o=e.querySelector("a[href]");return o!=null&&o.href?q(o.href):null}function Le(n){return n.length>=8&&!/\s/.test(n)}function tt(n){const e=n.getAttribute("href")||n.getAttribute("data-href")||n.getAttribute("data-url");if(e){const r=q(e);if(r)return r}const t=n.dataset;if(t)for(const[r,i]of Object.entries(t)){if(!i)continue;const a=r.toLowerCase();if((a.includes("conversation")||a.includes("chat")||a==="id"||a.endsWith("id"))&&Le(i))return i}const o=["data-conversation-id","data-id","data-chat-id","data-uuid"];for(const r of o){const i=n.getAttribute(r);if(i&&Le(i))return i}return null}function Ht(n){const e=tt(n);if(e)return e;const t=n.querySelector("a[href]");if(t!=null&&t.href){const r=q(t.href);if(r)return r}const o=n.querySelectorAll("*");for(const r of Array.from(o)){const i=tt(r);if(i)return i;if(r instanceof HTMLAnchorElement&&r.href){const a=q(r.href);if(a)return a}}return null}function Ft(n){var i,a,s;const e=n.trim();if(!e)return null;const t=mt();if(!t)return null;const o=Array.from(t.querySelectorAll("a[href]"));for(const l of o)if((l.textContent||"").trim()===e){const d=q(l.href);if(d)return d}const r=Array.from(t.querySelectorAll("[data-conversation-id], [data-id], [data-chat-id]"));for(const l of r)if((l.textContent||"").trim()===e){const d=((i=l.dataset)==null?void 0:i.conversationId)||((a=l.dataset)==null?void 0:a.id)||((s=l.dataset)==null?void 0:s.chatId);if(d&&Le(d))return d}return null}function He(n){var i,a;if(!n)return null;const e=n,t=((i=e.dataset)==null?void 0:i.conversationId)||((a=e.dataset)==null?void 0:a.id);if(t)return t;const o=Ht(e);if(o)return o;const r=(e.textContent||"").trim();return r?Ft(r):null}const zt=[{color:"#1f1f1f",label:"Black"},{color:"#E85C5C",label:"Red"},{color:"#F97316",label:"Orange"},{color:"#F59E0B",label:"Yellow"},{color:"#22C55E",label:"Green"},{color:"#3B82F6",label:"Blue"},{color:"#8B5CF6",label:"Purple"},{color:"#EC4899",label:"Pink"}],he=[{id:"default",label:"Folder",svg:'<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>'},{id:"investing",label:"Investing",svg:'<rect width="20" height="12" x="2" y="6" rx="2"/><circle cx="12" cy="12" r="2"/><path d="M6 12h.01M18 12h.01"/>'},{id:"phone",label:"Phone",svg:'<rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><path d="M12 18h.01"/>'},{id:"homework",label:"Homework",svg:'<path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/>'},{id:"writing",label:"Writing",svg:'<path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.375 2.625a2.121 2.121 0 1 1 3 3L12 15l-4 1 1-4Z"/>'},{id:"pen",label:"Pen",svg:'<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>'},{id:"coding",label:"Coding",svg:'<path d="m18 16 4-4-4-4"/><path d="m6 8-4 4 4 4"/><path d="m14.5 4-5 16"/>'},{id:"terminal",label:"Terminal",svg:'<polyline points="4 17 10 11 4 5"/><line x1="12" x2="20" y1="19" y2="19"/>'},{id:"music",label:"Music",svg:'<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>'},{id:"popcorn",label:"Movies",svg:'<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M7 3v18"/><path d="M3 7.5h4"/><path d="M3 12h18"/><path d="M3 16.5h4"/><path d="M17 3v18"/><path d="M17 7.5h4"/><path d="M17 16.5h4"/>'},{id:"travel",label:"Travel",svg:'<polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/><line x1="9" x2="9" y1="3" y2="18"/><line x1="15" x2="15" y1="6" y2="21"/>'},{id:"palette",label:"Art",svg:'<circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.555C21.965 6.012 17.461 2 12 2z"/>'},{id:"health",label:"Health",svg:'<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>'},{id:"flower",label:"Nature",svg:'<path d="M12 7.5a4.5 4.5 0 1 1 4.5 4.5M12 7.5A4.5 4.5 0 1 0 7.5 12M12 7.5V9m-4.5 3a4.5 4.5 0 1 0 4.5 4.5M7.5 12H9m7.5 0a4.5 4.5 0 1 1-4.5 4.5m4.5-4.5H15m-3 4.5V15"/><circle cx="12" cy="12" r="3"/><path d="m8 16 1.5-1.5"/><path d="M14.5 9.5 16 8"/><path d="m8 8 1.5 1.5"/><path d="M14.5 14.5 16 16"/>'},{id:"lotus",label:"Wellness",svg:'<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 13-1.8 17-4.7 5-9.5 3-14.2 3"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>'},{id:"briefcase",label:"Work",svg:'<rect width="20" height="14" x="2" y="7" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>'},{id:"chart",label:"Analytics",svg:'<path d="M3 3v18h18"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>'},{id:"apple",label:"Food",svg:'<path d="M12 20.94c1.5 0 2.75 1.06 4 1.06 3 0 6-8 6-12.22A4.91 4.91 0 0 0 17 5c-2.22 0-4 1.44-5 2-1-.56-2.78-2-5-2a4.9 4.9 0 0 0-5 4.78C2 14 5 22 8 22c1.25 0 2.5-1.06 4-1.06Z"/><path d="M10 2c1 .5 2 2 2 5"/>'},{id:"dumbbell",label:"Fitness",svg:'<path d="m6.5 6.5 11 11"/><path d="m21 21-1-1"/><path d="m3 3 1 1"/><path d="m18 22 4-4"/><path d="m2 6 4-4"/><path d="m3 10 7-7"/><path d="m14 21 7-7"/>'},{id:"notebook",label:"Notes",svg:'<path d="M2 6h4"/><path d="M2 10h4"/><path d="M2 14h4"/><path d="M2 18h4"/><rect width="16" height="20" x="4" y="2" rx="2"/><path d="M9.5 8h5"/><path d="M9.5 12H16"/><path d="M9.5 16H14"/>'},{id:"scale",label:"Legal",svg:'<path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="M7 21h10"/><path d="M12 3v18"/><path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2"/>'},{id:"globe",label:"Web",svg:'<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>'},{id:"airplane",label:"Flights",svg:'<path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"/>'},{id:"world",label:"Global",svg:'<circle cx="12" cy="12" r="10"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/><path d="M2 12h20"/>'},{id:"paw",label:"Pets",svg:'<circle cx="11" cy="4" r="2"/><circle cx="18" cy="8" r="2"/><circle cx="20" cy="16" r="2"/><path d="M9 10a5 5 0 0 1 5 5v3.5a3.5 3.5 0 0 1-6.84 1.045Q6.52 17.48 4.46 16.84A3.5 3.5 0 0 1 5.5 10Z"/>'},{id:"people",label:"Social",svg:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>'},{id:"beaker",label:"Science",svg:'<path d="M10 2v7.527a2 2 0 0 1-.211.896L4.72 20.55a1 1 0 0 0 .9 1.45h12.76a1 1 0 0 0 .9-1.45l-5.069-10.127A2 2 0 0 1 14 9.527V2"/><path d="M8.5 2h7"/><path d="M7 16h10"/>'},{id:"clover",label:"Luck",svg:'<path d="M12 7.5a4.5 4.5 0 1 1 4.5 4.5M12 7.5A4.5 4.5 0 1 0 7.5 12M12 7.5V9m-4.5 3a4.5 4.5 0 1 0 4.5 4.5M7.5 12H9m7.5 0a4.5 4.5 0 1 1-4.5 4.5m4.5-4.5H15m-3 4.5V15"/><circle cx="12" cy="12" r="3"/>'},{id:"heart",label:"Favorites",svg:'<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>'},{id:"research",label:"Research",svg:'<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>'}];function X(n,e){const t=he.find(r=>r.id===n)||he[0];return`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" 
         fill="none" stroke="${e||"currentColor"}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      ${t.svg}
    </svg>
  `}function _t(n){var e;return((e=he.find(t=>t.id===n))==null?void 0:e.label)||"Folder"}const ke="data-gp-active-row",Fe="data-gp-conversation-id",ge="data-gp-item",vt="data-gp-divider",pe="data-gp-menu-observer",V=["share conversation","share","pin","rename","delete","分享","置顶","重命名","删除"],_={fontFamily:'"Google Sans Flex", "Google Sans", "Helvetica Neue", sans-serif',fontSize:"14px",fontWeight:"500",color:"#1f1f1f",lineHeight:"20px",background:"#ffffff",borderRadius:"16px",boxShadow:"0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06), 0 12px 24px -4px rgba(0, 0, 0, 0.15)",border:"1px solid rgba(60, 64, 67, 0.08)",hover:"rgba(68, 71, 70, 0.08)",divider:"rgba(60, 64, 67, 0.08)",itemRadius:"10px",itemPadding:"4px 12px",itemHeight:"auto"},Ut={..._,background:"#1e1e1e",color:"#e3e3e3",border:"1px solid #444746",boxShadow:"0 4px 6px -1px rgba(0, 0, 0, 0.4), 0 12px 24px -4px rgba(0, 0, 0, 0.5)",hover:"rgba(255, 255, 255, 0.1)",divider:"rgba(255, 255, 255, 0.12)"};let le={..._},O=null,ye=null,Pe=!1,Y=null,L=null,v=null,ae=null,me=null;function P(...n){console.log("[gp-menu]",...n)}function je(n){if(!n)return"null";const e=n.getAttribute("aria-label")||"",t=n.getAttribute("role")||"",o=(n.textContent||"").trim().slice(0,24);return`${n.tagName.toLowerCase()} role=${t} label=${e} text="${o}"`}function Gt(n){const e=n.getBoundingClientRect();return`${Math.round(e.left)},${Math.round(e.top)} ${Math.round(e.width)}x${Math.round(e.height)}`}function nt(){const n=document.querySelector(`[${ke}="true"]`);n&&(n.removeAttribute(ke),n.removeAttribute(Fe)),ye&&(window.clearTimeout(ye),ye=null)}function Vt(n){nt(),n&&(n.setAttribute(ke,"true"),ye=window.setTimeout(()=>nt(),2e3))}P("menus.ts debug enabled");function Wt(n){const e=rn(n);return O=(t,o,r)=>{e.setActiveItem(r),e.open(t,o)},Pe?null:(Pe=!0,document.addEventListener("pointerdown",t=>{const o=t.target;if(!o)return;const r=!!o.closest('nav, aside, [role="navigation"], [role="complementary"]');if(r&&P("pointerdown",je(o)),!ot(o)){r&&P("not a kebab",je(o.closest('button,[role="button"],div,[aria-label]')));return}G("new menu");const i=ze(o);Vt(i),P("kebab click captured");const a=rt(o);P("conversationId",a),a?i&&i.setAttribute(Fe,a):P("conversationId missing at click"),Zt(o).then(s=>{if(!s){P("menu root not found");return}P("menuRoot found:",s.tagName.toLowerCase(),"rect=",Gt(s),"hits=",ee(s,V));const l=a||rt(o);if(!l){P("conversationId missing at inject time");return}kt(s,l,o,0)})},!0),document.addEventListener("click",t=>{const o=t.target;if(!o)return;const r=(v==null?void 0:v.contains(o))??!1,i=(Y==null?void 0:Y.contains(o))??!1,a=ot(o);!r&&!i&&!a&&G("outside click")}),document.addEventListener("scroll",()=>G("scroll"),!0),document.addEventListener("keydown",t=>{t.key==="Escape"&&G("esc")}),()=>{Pe=!1,O=null})}function ot(n){var c;const e=n.closest('button,[role="button"],div,[aria-label]');if(!e)return!1;const t=ze(e),r=(e.getAttribute("aria-label")||e.getAttribute("title")||"").toLowerCase(),i=e.getAttribute("aria-haspopup")==="menu"||e.getAttribute("aria-expanded")==="true",a=(e.textContent||"").trim(),s=a==="⋮"||a==="..."||a==="…",l=["more","menu","options","open menu","conversation actions","open menu for conversation actions","更多","菜单","选项"].some(b=>r.includes(b)),d=!!((c=t==null?void 0:t.querySelector)!=null&&c.call(t,"a[href]")),g=!!e.closest('nav, aside, [role="navigation"], [role="complementary"]');return l&&g?!0:(i||s||l)&&(d||g)}function Zt(n){return new Promise(e=>{let t=!1;const o=l=>{t||(t=!0,r.disconnect(),e(l))},r=new MutationObserver(l=>{for(const d of l)for(const g of Array.from(d.addedNodes)){const c=Kt(g);if(c){o(c);return}}});r.observe(document.body,{childList:!0,subtree:!0});let i=0;const a=30,s=()=>{if(t)return;const l=xt(n);if(l){o(l);return}if(i+=1,i>=a){o(null);return}requestAnimationFrame(s)};requestAnimationFrame(s)})}function Kt(n){if(!(n instanceof HTMLElement))return null;if(Ie(n))return n;const e=n.querySelector('[role="menu"], [role="listbox"]');if(e&&Ie(e))return e;const t=n.querySelector('[role="menuitem"]');if(t){const o=t.closest('[role="menu"], [role="listbox"]')||t.parentElement;if(o&&Ie(o))return o}return null}function yt(){const n=[document],e=document.createTreeWalker(document.body,NodeFilter.SHOW_ELEMENT);let t=e.currentNode;for(;t;){const o=t;o.shadowRoot&&n.push(o.shadowRoot),t=e.nextNode()}return n}function xt(n){var i;const e=yt(),t=[];e.forEach(a=>{t.push(...Array.from(a.querySelectorAll('[role="menu"], [role="listbox"]')))});const o=t.filter(a=>J(a));if(!o.length)return null;const r=o.map(a=>{const s=a.getBoundingClientRect(),l=s.width*s.height;return{menu:a,hits:ee(a,V),area:l}}).sort((a,s)=>s.hits!==a.hits?s.hits-a.hits:a.area-s.area);if(((i=r[0])==null?void 0:i.hits)>=2)return r[0].menu;if(n){const a=Yt(n);return a||Qt(o,n)}return Xt(o)}function Yt(n){const e=n.getBoundingClientRect(),t=Math.min(window.innerWidth-4,Math.max(0,e.right+8)),o=Math.min(window.innerHeight-4,Math.max(0,e.top+8)),r=document.elementFromPoint(t,o);if(!r)return null;const i=r.closest('[role="menu"], [role="listbox"]');return i&&J(i)?i:null}function Qt(n,e){const t=e.getBoundingClientRect();let o=null,r=Number.POSITIVE_INFINITY;return n.forEach(i=>{const a=i.getBoundingClientRect(),s=a.left-t.right,l=a.top-t.top,d=Math.sqrt(s*s+l*l);d<r&&(r=d,o=i)}),o}function Xt(n){let e=null,t=-1/0;return n.forEach(o=>{const r=Jt(o);r>t&&(t=r,e=o)}),e||n[0]||null}function Jt(n){const e=window.getComputedStyle(n).zIndex,t=Number(e);return Number.isFinite(t)?t:0}function Ie(n){if(ee(n,V)>=2)return!0;const t=n.querySelectorAll('[role="menuitem"], button, div');return(n.getAttribute("role")==="menu"||n.getAttribute("role")==="listbox")&&t.length>=3&&t.length<=12}function rt(n){const t=document.querySelector(`[${ke}="true"]`)||ze(n);if(t){const o=t.getAttribute(Fe);if(o)return o}return He(t)}function wt(n,e){if(!O)return!1;let t=on(n);if(t=ln(t),t===document.body||t===document.documentElement)return!1;Y=t,Ce(`[${ge}="move-to-project"]`).forEach(f=>{t.contains(f)||f.remove()}),Ce(`[${vt}="move-to-project"]`).forEach(f=>{t.contains(f)||f.remove()});const o=t.querySelector(`[${ge}="move-to-project"]`);o&&o.remove();const{container:r,deleteItem:i}=sn(t);if(!r||r===document.body||r===document.documentElement)return!1;const a=document.createElement("div");a.setAttribute("role","menuitem"),a.setAttribute(ge,"move-to-project"),a.style.display="flex",a.style.alignItems="center",a.style.gap="12px",a.style.setProperty("height","32px","important"),a.style.setProperty("min-height","32px","important"),a.style.setProperty("max-height","32px","important"),a.style.setProperty("padding","0 12px","important"),a.style.setProperty("margin","2px 0","important"),a.style.setProperty("box-sizing","border-box","important"),a.style.setProperty("cursor","pointer","important"),a.style.setProperty("border-radius","4px","important"),a.style.setProperty("background","transparent","important"),a.style.setProperty("color","inherit","important"),a.style.setProperty("border","none","important"),a.style.setProperty("outline","none","important"),a.style.setProperty("font-family",'"Google Sans Flex", "Google Sans", "Helvetica Neue", sans-serif',"important"),a.style.setProperty("font-size","14px","important"),a.style.setProperty("font-weight","500","important"),a.style.setProperty("line-height","20px","important");const s=document.createElement("span");s.style.setProperty("width","18px","important"),s.style.setProperty("height","18px","important"),s.style.setProperty("flex","0 0 18px","important"),s.style.display="inline-flex",s.style.alignItems="center",s.style.justifyContent="center",s.innerHTML=`
    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 2H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z" />
      <path d="m12 10 3 3-3 3" />
      <path d="M15 13H8" />
    </svg>
  `;const l=document.createElement("span");l.textContent="Move to Project",l.style.flex="1";const d=document.createElement("span");d.style.display="flex",d.style.alignItems="center",d.style.opacity="0.6",d.innerHTML=`
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M10 17l5-5-5-5"/>
    </svg>
  `,a.appendChild(s),a.appendChild(l),a.appendChild(d),a.addEventListener("mouseenter",()=>{const f=document.body.classList.contains("dark")||document.body.classList.contains("dark-theme");a.style.background=f?"rgba(255, 255, 255, 0.1)":"rgba(68, 71, 70, 0.08)",O==null||O(a.getBoundingClientRect(),e,a)}),a.addEventListener("mouseleave",()=>{a.style.background="transparent"}),a.addEventListener("click",()=>{O==null||O(a.getBoundingClientRect(),e,a)});const g=(i==null?void 0:i.parentNode)||r;i!=null&&i.parentNode?i.parentNode.insertBefore(a,i.nextSibling):g.appendChild(a);const c=t.getBoundingClientRect(),b=a.getBoundingClientRect();P("menuRoot rect=",`${Math.round(c.left)},${Math.round(c.top)} ${Math.round(c.width)}x${Math.round(c.height)}`),P("injected item height=",Math.round(b.height),"rect=",`${Math.round(b.left)},${Math.round(b.top)} ${Math.round(b.width)}x${Math.round(b.height)}`);const u=en(a,r);return P("injected ok:",`inRoot=${t.contains(a)}`,`overlap=${u.overlap.toFixed(2)}`,`container=${je(r)}`),u.passed?(nn(t,e),!0):(a.remove(),!1)}function en(n,e){const t=e.getBoundingClientRect(),o=n.getBoundingClientRect(),r=tn(t,o),i=Math.max(1,o.width*o.height),a=r/i;return{passed:e.contains(n)&&a>=.95,overlap:a}}function tn(n,e){const t=Math.max(n.left,e.left),o=Math.max(n.top,e.top),r=Math.min(n.right,e.right),i=Math.min(n.bottom,e.bottom),a=Math.max(0,r-t),s=Math.max(0,i-o);return a*s}function nn(n,e){if(n.getAttribute(pe)==="true")return;n.setAttribute(pe,"true");let t=0;L&&L.disconnect(),L=new MutationObserver(()=>{if(!document.contains(n)||!J(n)){L==null||L.disconnect(),n.removeAttribute(pe),G("menu root gone");return}!n.querySelector(`[${ge}="move-to-project"]`)&&t<3&&(t+=1,P("reinjected (observer) count=",t),wt(n,e))}),L.observe(n,{childList:!0,subtree:!0}),window.setTimeout(()=>{L==null||L.disconnect(),n.removeAttribute(pe)},800)}function J(n){const e=n.getBoundingClientRect(),t=e.width>0&&e.height>0&&e.right>0&&e.bottom>0&&e.left<window.innerWidth&&e.top<window.innerHeight,o=e.width<window.innerWidth*.9&&e.height<window.innerHeight*.9,r=e.width*e.height,i=window.getComputedStyle(n);return t&&o&&r>2e3&&i.pointerEvents!=="none"&&i.display!=="none"&&i.visibility!=="hidden"}function on(n){if(J(n)&&ee(n,V)>=2)return n;const e=Array.from(n.querySelectorAll('div, button, [role="menuitem"]'));for(const t of e){const o=(t.textContent||"").toLowerCase();if(!V.some(i=>o.includes(i)))continue;let r=t.parentElement;for(;r&&r!==document.body;){if(ee(r,V)>=2&&J(r))return r;r=r.parentElement}}return n}function ee(n,e){let t=0;return n.querySelectorAll('div, button, [role="menuitem"]').forEach(r=>{const i=(r.textContent||"").toLowerCase();e.some(a=>i.includes(a))&&(t+=1)}),t}function rn(n){function e(){return v&&document.contains(v)?(t(v),v):(v=document.createElement("div"),v.className="gp-move-menu",v.style.position="fixed",v.style.minWidth="220px",t(v),v.style.padding="6px",v.style.display="none",v.style.pointerEvents="auto",v.style.zIndex="2147483647",v.addEventListener("mouseenter",()=>{d()}),v.addEventListener("mouseleave",()=>{l()}),document.body.appendChild(v),v)}function t(c){const u=document.body.classList.contains("dark-theme")||document.body.classList.contains("dark")?Ut:_;if(le={...u},c.style.background=u.background,c.style.backdropFilter=u.backdropFilter||"",c.style.borderRadius=u.borderRadius,c.style.boxShadow=u.boxShadow,c.style.border=u.border,c.style.fontFamily=u.fontFamily,c.style.fontSize=u.fontSize,c.style.fontWeight=u.fontWeight,c.style.color=u.color,c.style.transformOrigin="top left",c.style.animation="gp-scale-in 0.15s cubic-bezier(0.2, 0, 0.13, 1.5)",!document.getElementById("gp-submenu-styles")){const f=document.createElement("style");f.id="gp-submenu-styles",f.textContent=`
        @keyframes gp-scale-in {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
      `,document.head.appendChild(f)}}function o(c){const b=n.getProjects(),u=n.getChatProjectId(c),f=[`<div class="gp-move-item secondary" data-gp-move="new">${X("default","#444746")}<span>New Project</span></div>`,'<div class="gp-move-divider"></div>',...b.map(p=>`<div class="gp-move-item" data-gp-move="${p.id}">${X(p.icon,p.color||"#444746")}<span>${an(p.name)}</span></div>`)];u&&(f.push('<div class="gp-move-divider"></div>'),f.push('<div class="gp-move-item" data-gp-move="remove">Remove from Project</div>'));const h=e();h.innerHTML=f.join(""),h.querySelectorAll(".gp-move-item").forEach(p=>{p.style.display="flex",p.style.alignItems="center",p.style.gap="12px",p.style.padding=_.itemPadding,p.style.minHeight="32px",p.style.borderRadius=_.itemRadius,p.style.cursor="pointer",p.style.fontSize=_.fontSize,p.style.fontWeight=le.fontWeight,p.style.color=le.color,p.style.lineHeight=_.lineHeight,p.style.fontFamily=_.fontFamily,p.style.transition="all 0.15s ease",p.addEventListener("mouseenter",()=>{p.style.background=le.hover}),p.addEventListener("mouseleave",()=>{p.style.background="transparent",p.style.transform="none"})}),h.querySelectorAll(".gp-move-divider").forEach(p=>{p.style.height="1px",p.style.background=le.divider,p.style.margin="4px 6px"}),h.querySelectorAll(".gp-move-item svg").forEach(p=>{p.setAttribute("width","18"),p.setAttribute("height","18")})}function r(c,b){const u=e();o(b),u.style.display="block",u.style.visibility="hidden",u.style.left="0px",u.style.top="0px",requestAnimationFrame(()=>{if(!u.isConnected)return;const f=240,h=u.offsetHeight,p=c.right+f>window.innerWidth?c.left-f:c.right,x=8;let M=c.top;M+h+x>window.innerHeight&&(M=window.innerHeight-h-x),M=Math.max(x,M),u.style.left=`${Math.max(8,p)}px`,u.style.top=`${M}px`,u.style.visibility="visible";const S=u.getBoundingClientRect();P("submenu opened (stable)",Math.round(S.left),Math.round(S.top),"size=",Math.round(S.width),"x",Math.round(S.height))}),u.onclick=f=>{const h=f.target.closest("[data-gp-move]");if(!h)return;const p=h.dataset.gpMove;if(p==="new"){n.onCreateProject(),G("submenu new");return}if(p==="remove"){n.onMoveChat(b,null),G("submenu remove");return}n.onMoveChat(b,p||null),G("submenu select")},document.addEventListener("mousemove",a,!0)}function i(){v&&(v.remove(),v=null),document.removeEventListener("mousemove",a,!0),me=null}function a(c){if(!v||!me)return;const b=c.target,u=v.contains(b),f=me.contains(b);!u&&!f?l():d()}function s(c){return(v==null?void 0:v.contains(c))??!1}function l(){ae&&clearTimeout(ae),ae=window.setTimeout(()=>{i()},200)}function d(){ae&&(clearTimeout(ae),ae=null)}function g(c){me=c}return{open:r,close:i,contains:s,startCloseTimer:l,cancelCloseTimer:d,setActiveItem:g}}function G(n){const e=Array.from(Ce(`[${ge}="move-to-project"]`)),t=Array.from(Ce(`[${vt}="move-to-project"]`));e.forEach(r=>r.remove()),t.forEach(r=>r.remove());let o=0;v&&(v.remove(),v=null,o=1),L&&(L.disconnect(),L=null),Y&&(Y.removeAttribute(pe),Y=null),P("cleanup removed:",`moveItem=${e.length}`,`divider=${t.length}`,`submenu=${o}`,n)}function an(n){return n.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function ze(n){const e=n.closest("a[href]");if(e)return e.closest('[role="listitem"], li, div')??e;let t=n;for(;t&&t!==document.body;){if(t.querySelector("a[href]"))return t;t=t.parentElement}return n.closest('[role="listitem"], li, div')}function sn(n){const e=Array.from(n.querySelectorAll('[role="menuitem"], button, div')),t=e.find(i=>(i.textContent||"").toLowerCase().includes("delete")||(i.textContent||"").includes("删除"));if(t!=null&&t.parentElement&&n.contains(t.parentElement))return{container:t.parentElement,deleteItem:t};const o=n.querySelector('[role="menu"], [role="listbox"]');if(o&&o!==n&&J(o))return{container:o};const r=e.find(i=>{const a=(i.textContent||"").trim();if(!a||a.length>48)return!1;const s=i.getBoundingClientRect();return s.height>20&&s.height<80});return r!=null&&r.parentElement&&n.contains(r.parentElement)?{container:r.parentElement}:{container:n}}function ln(n){if((n.getAttribute("role")==="menu"||n.getAttribute("role")==="listbox")&&ee(n,V)>=2)return n;const t=Array.from(n.querySelectorAll('[role="menu"], [role="listbox"]')).filter(r=>J(r));if(!t.length)return n;const o=t.map(r=>{const i=r.getBoundingClientRect();return{menu:r,hits:ee(r,V),area:i.width*i.height}}).sort((r,i)=>i.hits!==r.hits?i.hits-r.hits:r.area-i.area)[0];return o&&o.hits>=1?o.menu:n}function Ce(n){const e=yt(),t=[];return e.forEach(o=>{t.push(...Array.from(o.querySelectorAll(n)))}),t}function kt(n,e,t,o){if(wt(n,e))return;if(o>=2){P("inject failed after retries");return}const i=xt(t)||n;requestAnimationFrame(()=>kt(i,e,t,o+1))}function cn(n){const e=pn(n.shadow),t=hn(n.overlayShadow),o=fn(t),r=mn(t),i=vn(t);xn(e,t);let a=null;const s=bn(t,()=>(a==null?void 0:a.projects)||[]);let l="create",d=null,g=null,c="default",b="#1f1f1f",u=!1,f=null,h=null;function p(y){a=y,e.innerHTML=gn(y),x(y)}function x(y){const k=e.querySelector('[data-gp-action="toggle-section"]'),T=e.querySelector('[data-gp-action="new-project"]');k==null||k.addEventListener("click",I=>{if(I.target.closest("button"))return;const $=y.uiPrefs.projectsCollapsed;n.onToggleCollapse(!$)}),T==null||T.addEventListener("click",()=>M()),e.querySelectorAll("[data-gp-project-id]").forEach(I=>{const $=I.dataset.gpProjectId,w=I.querySelector('[data-gp-action="project-menu"]'),C=I.querySelector('[data-gp-action="toggle-project"]');C==null||C.addEventListener("click",W=>{W.target.closest('[data-gp-action="project-menu"]')||n.onToggleProjectExpand($)}),w==null||w.addEventListener("click",W=>{W.stopPropagation();const Z=y.projects.find(ie=>ie.id===$);Z&&D(Z,w.getBoundingClientRect())}),I.querySelectorAll('[data-gp-action="chat-menu"]').forEach(W=>{const Z=W.closest("[data-gp-chat-id]");if(!Z)return;const ie=Z.dataset.gpChatId,Ue=Z.dataset.gpProjectId,fe=Z.querySelector(".gp-chat-link");fe==null||fe.addEventListener("click",N=>{N.button!==0||N.metaKey||N.ctrlKey||N.shiftKey||N.altKey||(N.preventDefault(),yn(ie,fe.href))}),W.addEventListener("click",N=>{N.stopPropagation(),N.preventDefault();const Ge=y.projects.find(Me=>Me.id===Ue);Ge&&s.open(W.getBoundingClientRect(),ie,Ue,Ge.name,{onRemove:()=>n.onRemoveChatFromProject(ie),onMoveToProject:Me=>n.onMoveChatToProject(ie,Me)})})})})}function M(){l="create",d=null,c="default",R({title:"Create Project",confirmLabel:"Create Project",name:"",showIcons:!0})}function S(y){l="edit",d=y.id,g=y,c=y.icon,b=y.color||"#1f1f1f",R({title:"Edit project",confirmLabel:"Save",name:y.name,showIcons:!0})}function A(){if(f){const y=b==="#1f1f1f"?void 0:b;f.innerHTML=X(c,y)}}function H(y,k,T,I){c=k,A(),!u&&T&&(T.value=y),I&&T&&(I.disabled=T.value.trim().length===0)}function R(y){o.open(y),u=!1;const k=o.element.querySelector("[data-gp-name-input]"),T=o.element.querySelector('[data-gp-action="confirm"]'),I=o.element.querySelector("[data-gp-template-row]");f=o.element.querySelector('[data-gp-action="icon-picker"]'),h=o.element.querySelector("[data-gp-icon-popover]"),k&&(k.value=y.name,k.focus()),I&&(I.style.display=y.showIcons?"flex":"none"),T.textContent=y.confirmLabel,T.disabled=(k==null?void 0:k.value.trim().length)===0,A(),k&&(k.oninput=()=>{u=!0,T.disabled=k.value.trim().length===0}),T.onclick=()=>{const w=(k==null?void 0:k.value.trim())??"";if(!w)return;const C=Date.now(),re={id:l==="create"?crypto.randomUUID():d,name:w,icon:c,color:b,createdAt:l==="create"?C:(g==null?void 0:g.createdAt)||C,updatedAt:C,sortIndex:l==="create"?C:(g==null?void 0:g.sortIndex)||C};n.onSaveProject(re),o.close()},f&&(f.onclick=w=>{w.stopPropagation(),h&&(h.style.display=h.style.display==="flex"?"none":"flex")}),o.element.onclick=w=>{const C=w.target;!h||!f||h.contains(C)||f.contains(C)||(h.style.display="none")},h==null||h.querySelectorAll("[data-gp-icon-option]").forEach(w=>{w.onclick=()=>{c=w.dataset.gpIconOption,A(),h&&(h.style.display="none")}}),I==null||I.querySelectorAll("[data-gp-template]").forEach(w=>{w.onclick=()=>{const C=w.dataset.gpTemplate,re=w.dataset.gpTemplateLabel||_t(C);H(re,C,k??void 0,T??void 0)}});const $=o.element.querySelector("[data-gp-color-row]");$==null||$.querySelectorAll("[data-gp-color]").forEach(w=>{w.onclick=()=>{const C=w.dataset.gpColor;C&&(b=C,$.querySelectorAll(".gp-color-dot").forEach(re=>re.classList.remove("selected")),w.classList.add("selected"),A())}})}function D(y,k){r.open(k,y,{onEdit:()=>S(y),onDelete:()=>n.onDeleteProject(y.id)})}function B(y){i.show(y)}function Lt(){o.close(),r.close(),i.hide()}return{render:p,closeAllOverlays:Lt,showToast:B,openCreateModal:M}}function dn(n,e,t){const o=[...n].sort((r,i)=>r.sortIndex-i.sortIndex);return o.length?o.map(r=>{const i=t.has(r.id),a=Array.from(e.values()).filter(l=>l.projectId===r.id).sort((l,d)=>d.updatedAt-l.updatedAt),s=i?`
          <div class="gp-project-chats">
            ${a.length?a.map(l=>`
                        <div class="gp-chat-row" data-gp-chat-id="${l.conversationId}" data-gp-project-id="${r.id}">
                          <a class="gp-chat-link" href="${ue(l.lastUrl||`/app/${l.conversationId}`)}">
                            <span class="gp-chat-title">${ue(l.title||"Untitled chat")}</span>
                          </a>
                          <button class="gp-chat-kebab" data-gp-action="chat-menu" aria-label="Chat menu"><svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><circle cx="12" cy="4" r="2.5"/><circle cx="12" cy="12" r="2.5"/><circle cx="12" cy="20" r="2.5"/></svg></button>
                        </div>
                      `).join(""):'<div class="gp-chat-empty">No chats yet</div>'}
          </div>
        `:"";return`
        <div class="gp-project" data-gp-project-id="${r.id}">
          <div class="gp-row gp-project-row ${i?"active":""}" data-gp-action="toggle-project">
            <span class="gp-icon">${X(r.icon,r.color)}</span>
            <span class="gp-label">${ue(r.name)}</span>
            <button class="gp-kebab" data-gp-action="project-menu" aria-label="Project menu"><svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg></button>
          </div>
          ${s}
        </div>
      `}).join(""):""}function pn(n){let e=n.getElementById("gp-panel-root");if(e||(e=document.createElement("div"),e.id="gp-panel-root",n.appendChild(e)),!n.querySelector('style[data-gp="panel"]')){const t=document.createElement("style");t.dataset.gp="panel",t.textContent=`
      :host {
        all: initial;
        font-family: inherit;
        color: var(--gp-fg, #1f1f1f);
        box-sizing: border-box;
        
        /* Native Fonts & Colors (Gemini) */
        --gp-font: "Google Sans Flex", "Google Sans", "Helvetica Neue", sans-serif;
        --gp-fg: #1f1f1f;
        --gp-fg-muted: #444746;
        --gp-bg-hover: rgba(68, 71, 70, 0.08); 
        --gp-bg-active: rgba(68, 71, 70, 0.12);
        
        --gp-radius: 24px;
        --gp-spacing-row: 0px;
        
        display: block;
        padding-top: 12px;
      }
      
      :host(.dark) {
        --gp-fg: #e3e3e3;
        --gp-fg-muted: #c4c7c5;
        --gp-bg-hover: rgba(255, 255, 255, 0.08); 
        --gp-bg-active: rgba(255, 255, 255, 0.12);
      }

      * {
        box-sizing: border-box;
      }

      .gp-panel {
        display: flex;
        flex-direction: column;
        gap: var(--gp-spacing-row);
        background: transparent;
        padding: 0;
      }

      /* GPT-Style Header (Projects v) */
      .gp-title {
        display: flex;
        align-items: center;
        justify-content: flex-start;
        gap: 2px; /* Close gap */
        
        margin: 0;
        /* Reverted to 12px as 16px was "Too Right" */
        padding: 0 12px; 
        
        height: 44px;
        color: var(--gp-fg); 
        font-family: var(--gp-font);
        font-size: 14px;
        font-weight: 500;
        line-height: 20px;
        cursor: pointer;
        user-select: none;
        border-radius: var(--gp-radius);
        transition: background 0.1s ease;
      }
      
      .gp-title:hover {
        background: var(--gp-bg-hover);
      }

      .gp-chevron {
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.2s cubic-bezier(0.2, 0, 0, 1);
        color: var(--gp-fg-muted);
        opacity: 0.6;
      }
      
      .gp-chevron svg {
        width: 18px; 
        height: 18px;
        /* Rounded Stroke Style */
        fill: none;
      }

      /* When collapsed, arrow points right (like text flow) 
         or logic: Collapsed = Arrow Right ( > ), Expanded = Arrow Down ( v )
         Currently: Expanded by default.
         If default Markup has arrow pointing down:
      */
      .gp-title.collapsed .gp-chevron {
        transform: rotate(-90deg); /* Points Right */
      }

      .gp-list-container {
        display: flex;
        flex-direction: column;
        gap: 0; /* Tightest packing */
        overflow: hidden;
        padding-top: 2px; /* Space between header and list */
      }
      
      .gp-list-container.hidden {
        display: none;
      }

      /* Standard Row (Floating Pill style) */
      .gp-row {
        display: flex;
        align-items: center;
        gap: 12px;
        
        /* Removed margin to align text with Gems */
        margin: 0;
        padding: 0 16px; /* Text/Icon starts at 16+12=28px from screen edge */
        
        height: 48px;
        border-radius: var(--gp-radius);
        text-decoration: none;
        color: var(--gp-fg);
        cursor: pointer;
        font-family: var(--gp-font);
        font-size: 14px;
        font-weight: 500;
        line-height: 20px;
        position: relative;
        transition: background 0.1s ease;
      }

      .gp-row:hover {
        background: var(--gp-bg-hover);
      }
      
      /* Removed: Active state background creates visual clutter with stacked pill shapes.
         Only hover is now highlighted for a cleaner look.
      .gp-row.active {
        background: var(--gp-bg-active);
      }
      */

      .gp-label {
        flex: 1;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .gp-new .gp-icon {
        color: var(--gp-fg);
      }

      .gp-icon {
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        color: var(--gp-fg-muted);
      }
      
      .gp-icon svg { width: 18px; height: 18px; }

      .gp-kebab {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        border: none;
        background: transparent;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--gp-fg-muted);
        cursor: pointer;
        opacity: 0;
        transition: background 0.15s ease, opacity 0.15s ease;
        margin-right: -8px;
        flex-shrink: 0;
      }
      
      .gp-kebab svg {
        width: 20px;
        height: 20px;
      }
      
      .gp-row:hover .gp-kebab, 
      .gp-kebab:focus {
        opacity: 1;
      }
      
      .gp-kebab:hover {
        background: rgba(68, 71, 70, 0.12);
        color: var(--gp-fg);
      }

      .gp-project-chats {
        display: flex;
        flex-direction: column;
        gap: 2px;
        position: relative;
        /* Tree connector line - vertical bar on left side */
        margin-left: 28px; /* Aligns with icon center: 16px padding + 12px (half of 24px icon) */
        padding-left: 24px; /* Space for the line */
        border-left: 1.5px solid rgba(68, 71, 70, 0.15); /* Subtle connector line */
      }

      .gp-chat-row {
        height: 36px;
        /* Scaled padding (16px * 0.75 = 12px) to match project row proportions */
        padding: 0 12px 0 12px;
        margin: 0;
        display: flex;
        align-items: center;
        text-decoration: none;
        color: var(--gp-fg-muted);
        font-family: var(--gp-font);
        font-size: 13px;
        font-weight: 500;
        line-height: 20px;
        border-radius: var(--gp-radius);
        transition: background 0.1s;
      }
      
      .gp-chat-row:hover {
        background: var(--gp-bg-hover);
      }
      
      .gp-chat-row:hover .gp-chat-link {
        color: var(--gp-fg);
      }

      .gp-chat-link {
        flex: 1;
        min-width: 0; /* Allow text truncation */
        display: flex;
        align-items: center;
        height: 100%;
        text-decoration: none;
        color: inherit;
      }

      .gp-chat-title {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      
      .gp-chat-kebab {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        border: none;
        background: transparent;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--gp-fg-muted);
        cursor: pointer;
        opacity: 0;
        transition: background 0.15s ease, opacity 0.15s ease;
        margin-right: -6px; /* Scaled margin (-8px * 0.75 = -6px) */
        flex-shrink: 0;
      }
      
      .gp-chat-kebab svg {
        width: 18px;
        height: 18px;
      }
      
      .gp-chat-row:hover .gp-chat-kebab {
        opacity: 1;
      }
      
      .gp-chat-kebab:hover {
        background: rgba(68, 71, 70, 0.12);
        color: var(--gp-fg);
      }
      
      .gp-chat-empty {
        padding: 8px 16px 8px 52px;
        margin: 0;
        font-size: 12px;
        color: #8e918f;
        font-style: italic;
      }
    `,n.appendChild(t)}return e}function gn(n){const e=n.uiPrefs.projectsCollapsed;return`
    <div class="gp-panel">
      <!-- Header with Chevron -->
      <div class="gp-title ${e?"collapsed":""}" data-gp-action="toggle-section" role="button">
        <span>Projects</span>
        <span class="gp-chevron">
    <svg viewBox="0 0 24 24">
      <path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
  </span>
      </div>
      
      <!-- Collapsible Container -->
      <div class="gp-list-container ${e?"hidden":""}">
        <div class="gp-row gp-new" data-gp-action="new-project">
          <span class="gp-icon"><svg viewBox="0 0 24 24" width="18" height="18" style="color: #444746;"><path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></span>
          <span class="gp-label">New Project</span>
        </div>
        ${dn(n.projects,n.chatIndex,n.expandedProjectIds)}
      </div>
    </div>
  `}function ue(n){return n.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function un(){return`
    <div class="gp-namebox" data-gp-namebox>
      <button class="gp-icon-button" type="button" data-gp-action="icon-picker" aria-label="Choose icon"></button>
      <input class="gp-name-input" data-gp-name-input type="text" placeholder="Project name" />
      <div class="gp-icon-popover" data-gp-icon-popover>
        <div class="gp-icon-grid">
          ${he.map(n=>`
              <button class="gp-icon-option" type="button" data-gp-icon-option="${n.id}" title="${n.label}">
                ${X(n.id)}
              </button>
            `).join("")}
        </div>
      </div>
    </div>
  `}function hn(n){let e=n.getElementById("gp-overlay-layer");if(e||(e=document.createElement("div"),e.id="gp-overlay-layer",n.appendChild(e)),!n.querySelector('style[data-gp="overlay"]')){const t=document.createElement("style");t.dataset.gp="overlay",t.textContent=`
      @import url('https://fonts.googleapis.com/css2?family=Fraunces:wght@400;500;600;700;800;900&display=swap');

      :host {
        all: initial;
        font-family: inherit;
        color: var(--gp-fg, #1b1a18);
        --gp-font: "Manrope", "Styrene A", "Styrene B", "Inter", "Segoe UI", sans-serif;
        --gp-font-serif: "Fraunces", "Times New Roman", serif;
        --gp-fg: #1b1a18;
        --gp-fg-muted: #5b5954;
        --gp-muted: #838079;
        --gp-border: rgba(91, 89, 84, 0.24);
        --gp-hover: rgba(91, 89, 84, 0.08);
        --gp-hover-strong: rgba(91, 89, 84, 0.14);
        --gp-surface: #ede9e0;
        --gp-surface-2: #f5f2ea;
        --gp-shadow: 0 20px 48px -12px rgba(27, 26, 24, 0.35);
        --gp-radius-xs: 8px;
        --gp-radius-sm: 10px;
        --gp-radius: 12px;
        --gp-radius-lg: 16px;
        --gp-radius-xl: 20px;
        --gp-radius-pill: 999px;
        --gp-accent: #1b1a18;
        --gp-on-accent: #ede9e0;
        --gp-accent-hover: rgba(27, 26, 24, 0.08);
        --gp-focus: #d97c5d;
        --gp-input-bg: rgba(251, 250, 246, 0.76);
      }
      
      :host(.dark) {
        --gp-fg: #ede9e0;
        --gp-fg-muted: #c9c5bc;
        --gp-muted: #a4a19b;
        --gp-border: rgba(237, 233, 224, 0.2);
        --gp-hover: rgba(237, 233, 224, 0.1);
        --gp-hover-strong: rgba(237, 233, 224, 0.16);
        --gp-surface: #1b1a18;
        --gp-surface-2: #23201d;
        --gp-shadow: 0 22px 52px -14px rgba(0, 0, 0, 0.72);
        --gp-accent: #ede9e0;
        --gp-on-accent: #1b1a18;
        --gp-accent-hover: rgba(237, 233, 224, 0.12);
        --gp-focus: #d97c5d;
        --gp-input-bg: rgba(35, 33, 30, 0.84);
      }

      .gp-modal-backdrop {
        position: fixed;
        inset: 0;
        background: rgba(27, 26, 24, 0.34);
        display: none;
        align-items: center;
        justify-content: center;
        pointer-events: auto;
      }
      .gp-modal {
        background: var(--gp-surface);
        border-radius: var(--gp-radius-xl);
        width: 520px;
        max-width: calc(100vw - 32px);
        box-shadow: var(--gp-shadow);
        border: 1px solid var(--gp-border);
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 14px;
        font-family: var(--gp-font);
        color: var(--gp-fg);
        position: relative;
      }
      .gp-modal-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 19px;
        font-weight: 700;
        font-family: var(--gp-font-serif);
        letter-spacing: 0.01em;
        color: var(--gp-fg);
      }
      .gp-modal-header [data-gp-modal-title] {
        font-family: "Fraunces", serif;
        font-weight: 700;
        font-style: normal;
        font-variation-settings: normal;
        letter-spacing: 0;
        text-rendering: optimizeLegibility;
        -webkit-font-smoothing: antialiased;
      }
      .gp-modal-close {
        border: none;
        background: transparent;
        font-size: 18px;
        cursor: pointer;
        color: var(--gp-muted);
        width: 32px;
        height: 32px;
        border-radius: var(--gp-radius-pill);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: background 120ms ease;
      }
      .gp-modal-close svg { width: 18px; height: 18px; }
      .gp-modal-close:hover { background: var(--gp-hover); }
      .gp-namebox {
        display: flex;
        align-items: center;
        gap: 12px;
        border: 1px solid var(--gp-border);
        border-radius: var(--gp-radius-lg);
        padding: 8px; /* Uniform padding for consistent margins */
        position: relative;
        background: var(--gp-input-bg);
        transition: border-color 120ms ease, box-shadow 120ms ease;
      }
      .gp-namebox:focus-within {
        border-color: var(--gp-focus);
        box-shadow: 0 0 0 2px rgba(217, 124, 93, 0.22);
      }
      .gp-icon-button {
        width: 36px;
        height: 36px;
        border: none;
        border-radius: var(--gp-radius-sm);
        background: var(--gp-input-bg);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: box-shadow 120ms ease, background 120ms ease;
        color: var(--gp-fg);
      }
      .gp-icon-button:hover { background: var(--gp-hover); }
      .gp-icon-button svg { width: 18px; height: 18px; }
      .gp-icon-button:focus-visible {
        outline: none;
        box-shadow: 0 0 0 2px rgba(217, 124, 93, 0.3);
      }
      .gp-name-input {
        flex: 1;
        border: none;
        outline: none;
        background: transparent;
        font-size: 15px;
        color: var(--gp-fg);
        font-family: var(--gp-font);
      }
      .gp-name-input::placeholder { color: var(--gp-muted); }
      .gp-icon-popover {
        position: absolute;
        top: calc(100% + 10px);
        left: 0;
        background: var(--gp-surface);
        border-radius: 20px;
        border: 1px solid var(--gp-border);
        box-shadow: 0 14px 38px rgba(27, 26, 24, 0.24), 0 4px 12px rgba(27, 26, 24, 0.12);
        padding: 16px;
        display: none;
        z-index: 2147483647;
      }
      .gp-icon-grid {
        display: grid;
        /* 精确的6x5等距网格布局 */
        grid-template-columns: repeat(6, 1fr);
        gap: 8px;
        width: 288px; /* (40+8)*6 - 8 = 精确宽度 */
      }
      .gp-icon-option {
        width: 40px;
        height: 40px;
        border: 1.5px solid var(--gp-border);
        border-radius: 12px;
        background: var(--gp-surface);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 150ms cubic-bezier(0.4, 0, 0.2, 1);
        color: var(--gp-fg);
      }
      .gp-icon-option:hover {
        border-color: var(--gp-focus);
        background: var(--gp-accent-hover);
        transform: scale(1.05);
        box-shadow: 0 2px 8px rgba(27, 26, 24, 0.18);
      }
      .gp-icon-option:active {
        transform: scale(0.95);
      }
      .gp-icon-option svg { width: 18px; height: 18px; }
      .gp-icon-option:focus-visible {
        outline: none;
        box-shadow: 0 0 0 3px rgba(217, 124, 93, 0.35);
      }
      .gp-template-row {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        align-items: center;
      }
      .gp-template-chip {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        border-radius: var(--gp-radius-pill);
        border: 1px solid var(--gp-border);
        cursor: pointer;
        font-size: 13px;
        color: var(--gp-fg);
        background: var(--gp-surface);
        transition: background 120ms ease, border-color 120ms ease, box-shadow 120ms ease;
        line-height: 1;
        height: 32px;
        font-weight: 500;
      }
      .gp-template-chip:hover {
        background: var(--gp-hover);
        border-color: rgba(91, 89, 84, 0.36);
      }
      .gp-template-chip svg { width: 16px; height: 16px; }
      .gp-template-chip:focus-visible { outline: none; box-shadow: 0 0 0 2px rgba(217, 124, 93, 0.28); }
      
      /* Color Picker Row */
      .gp-color-row {
        display: flex;
        gap: 8px;
        align-items: center;
        margin-bottom: 8px;
      }
      .gp-color-dot {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: 2px solid transparent;
        cursor: pointer;
        transition: transform 0.15s ease, box-shadow 0.15s ease;
        padding: 0;
        position: relative;
        /* 立体磨砂效果基础 */
        overflow: hidden;
      }
      .gp-color-dot:hover {
        transform: scale(1.12);
      }
      .gp-color-dot.selected {
        box-shadow: 0 0 0 2px var(--gp-surface), 0 0 0 4px currentColor;
      }
      .gp-color-dot:first-child.selected {
        box-shadow: 0 0 0 2px var(--gp-surface), 0 0 0 4px #1f1f1f;
      }
      
      /* Adaptive Color (Black/White) */
      .gp-color-adaptive {
        background-color: #1f1f1f;
        color: #1f1f1f;
      }
      :host(.dark) .gp-color-adaptive {
        background-color: #ffffff;
        color: #ffffff;
      }
      :host(.dark) .gp-color-dot:first-child.selected {
        box-shadow: 0 0 0 2px var(--gp-surface), 0 0 0 4px #ffffff;
      }

      /* 所有颜色的立体磨砂效果 - 移除，回归扁平 */
      .gp-color-dot::before,
      .gp-color-dot::after {
        display: none;
      }
      .gp-color-dot:first-child::before,
      .gp-color-dot:first-child::after {
        display: none;
      }
      
      .gp-modal-actions {
        display: flex;
        justify-content: flex-end;
      }
      .gp-primary {
        background: var(--gp-accent);
        color: var(--gp-on-accent, #fff);
        border: none;
        padding: 8px 20px;
        border-radius: 12px; /* Rounded rectangle instead of pill - cleaner edges */
        cursor: pointer;
        font-weight: 600;
        box-shadow: 0 8px 18px -10px rgba(27, 26, 24, 0.55);
        transition: filter 120ms ease, transform 100ms ease;
        height: 40px;
        min-width: 140px;
      }
      .gp-primary:hover { filter: brightness(0.98); }
      .gp-primary:disabled {
        background: var(--gp-hover-strong);
        color: var(--gp-muted);
        cursor: not-allowed;
        box-shadow: none;
      }
      .gp-menu {
        position: fixed;
        min-width: 220px;
        background: var(--gp-surface);
        border-radius: 16px; /* Outer */
        box-shadow: 0 8px 20px -10px rgba(27, 26, 24, 0.35), 0 2px 8px rgba(27, 26, 24, 0.16);
        border: 1px solid var(--gp-border);
        padding: 6px; /* Padding: 6px */
        display: none;
        pointer-events: auto;
        font-family: var(--gp-font);
        color: var(--gp-fg);
        z-index: 2147483647;
      }
      .gp-menu-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 6px 12px; /* Tighter padding */
        border-radius: 10px; /* Inner: 16 - 6 = 10 */
        cursor: pointer;
        font-size: 14px;
        font-weight: 500;
        color: var(--gp-fg);
        line-height: 20px;
        transition: all 120ms ease;
      }
      .gp-menu-item:hover {
        background: var(--gp-hover);
        transform: none;
      }
      .gp-menu-item.danger { color: #b85a3e; }
      
      /* Chat menu item with icons */
      .gp-chat-menu .gp-menu-item {
        justify-content: flex-start;
        gap: 10px;
      }
      .gp-chat-menu .gp-menu-item svg {
        width: 18px;
        height: 18px;
        flex-shrink: 0;
      }
      .gp-chat-menu .gp-menu-item span {
        flex: 1;
      }
      
      /* Submenu trigger arrow */
      .gp-submenu-arrow {
        width: 16px;
        height: 16px;
        margin-left: auto;
        opacity: 0.6;
      }
      
      /* Submenu panel */
      .gp-submenu {
        position: fixed;
        min-width: 180px;
        background: var(--gp-surface);
        border-radius: 12px;
        box-shadow: 0 8px 20px -10px rgba(27, 26, 24, 0.35), 0 2px 8px rgba(27, 26, 24, 0.16);
        border: 1px solid var(--gp-border);
        padding: 4px;
        display: none;
        z-index: 2147483647;
        font-family: var(--gp-font);
      }
      .gp-submenu .gp-menu-item {
        justify-content: flex-start;
        gap: 8px;
        padding: 6px 10px;
        font-size: 13px;
        border-radius: 8px;
      }
      .gp-submenu .gp-menu-item svg {
        width: 16px;
        height: 16px;
      }
      .gp-toast {
        position: fixed;
        bottom: 24px;
        right: 24px;
        background: #1b1a18;
        color: #ede9e0;
        padding: 10px 16px;
        border-radius: var(--gp-radius-pill);
        font-size: 13px;
        display: none;
        pointer-events: auto;
        border: 1px solid rgba(255, 255, 255, 0.12);
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.25);
        font-family: var(--gp-font);
      }
    `,n.appendChild(t)}return e}function fn(n){const e=document.createElement("div");e.className="gp-modal-backdrop",e.innerHTML=`
    <div class="gp-modal" role="dialog" aria-modal="true">
      <div class="gp-modal-header">
        <span data-gp-modal-title>Create Project</span>
        <button class="gp-modal-close" data-gp-action="close" aria-label="Close">
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
          </svg>
        </button>
      </div>
      ${un()}
      <div class="gp-color-row" data-gp-color-row>
        ${zt.map((i,a)=>{const s=a===0,l=s?"":`background-color: ${i.color}; color: ${i.color};`;return`
            <button class="gp-color-dot ${a===0?"selected":""} ${s?"gp-color-adaptive":""}" 
                    data-gp-color="${i.color}" 
                    title="${i.label}"
                    style="${l}">
            </button>
          `}).join("")}
      </div>
      <div class="gp-template-row" data-gp-template-row>
        ${he.map(i=>`
            <div class="gp-template-chip" data-gp-template="${i.id}" data-gp-template-label="${i.label}">
              ${X(i.id)}
              <span>${i.label}</span>
            </div>
          `).join("")}
      </div>
      <div class="gp-modal-actions">
        <button class="gp-primary" data-gp-action="confirm" disabled>Create Project</button>
      </div>
    </div>
  `,n.appendChild(e);function t(i){const a=e.querySelector("[data-gp-modal-title]"),s=e.querySelector('[data-gp-action="confirm"]'),l=e.querySelector("[data-gp-name-input]"),d=e.querySelector("[data-gp-template-row]");a&&(a.textContent=i.title),s&&(s.textContent=i.confirmLabel),l&&(l.value=i.name),d&&(d.style.display=i.showIcons?"flex":"none");const g=e.querySelector("[data-gp-icon-popover]");g&&(g.style.display="none"),e.style.display="flex"}function o(){e.style.display="none"}e.addEventListener("click",i=>{i.target===e&&o()});const r=e.querySelector('[data-gp-action="close"]');return r==null||r.addEventListener("click",()=>o()),{element:e,open:t,close:o}}function mn(n){const e=document.createElement("div");e.className="gp-menu",n.appendChild(e);let t=null;function o(i,a,s){t=s,e.innerHTML=`
      <div class="gp-menu-item" data-gp-menu="edit">Edit Project</div>
      <div class="gp-menu-item danger" data-gp-menu="delete">Delete Project</div>
    `;const l=Math.min(i.left,window.innerWidth-220),d=i.bottom+6;e.style.left=`${l}px`,e.style.top=`${d}px`,e.style.display="block"}function r(){e.style.display="none"}return e.addEventListener("click",i=>{const a=i.target.closest("[data-gp-menu]");if(!a||!t)return;const s=a.dataset.gpMenu;s==="edit"&&t.onEdit(),s==="delete"&&t.onDelete(),r()}),document.addEventListener("click",i=>{e.contains(i.target)||r()}),document.addEventListener("keydown",i=>{i.key==="Escape"&&r()}),{open:o,close:r}}function bn(n,e){const t=document.createElement("div");t.className="gp-menu gp-chat-menu",n.appendChild(t);let o=null;function r(a,s,l,d,g){o=g;const c=e().filter(p=>p.id!==l);t.innerHTML=`
      <div class="gp-menu-item" data-gp-chat-action="remove">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
          <polyline points="16 17 21 12 16 7"/>
          <line x1="21" y1="12" x2="9" y2="12"/>
        </svg>
        <span>Remove from ${ue(d)}</span>
      </div>
      ${c.length>0?`
        <div class="gp-menu-item gp-submenu-trigger" data-gp-chat-action="move-trigger">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
            <line x1="12" y1="11" x2="12" y2="17"/>
            <line x1="9" y1="14" x2="15" y2="14"/>
          </svg>
          <span>Move to Project</span>
          <svg class="gp-submenu-arrow" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="9 18 15 12 9 6"/>
          </svg>
        </div>
        <div class="gp-submenu" data-gp-submenu="move">
          ${c.map(p=>`
            <div class="gp-menu-item" data-gp-chat-action="move" data-gp-target-project="${p.id}">
              ${X(p.icon,p.color)}
              <span>${ue(p.name)}</span>
            </div>
          `).join("")}
        </div>
      `:""}
    `;const b=Math.min(a.left,window.innerWidth-240),u=a.bottom+6;t.style.left=`${b}px`,t.style.top=`${u}px`,t.style.display="block";const f=t.querySelector(".gp-submenu-trigger"),h=t.querySelector(".gp-submenu");f&&h&&(f.addEventListener("mouseenter",()=>{h.style.display="block";const p=f.getBoundingClientRect();h.style.left=`${p.right-4}px`,h.style.top=`${p.top}px`}),f.addEventListener("mouseleave",p=>{const x=p.relatedTarget;x&&h.contains(x)||(h.style.display="none")}),h.addEventListener("mouseleave",()=>{h.style.display="none"}))}function i(){t.style.display="none";const a=t.querySelector(".gp-submenu");a&&(a.style.display="none")}return t.addEventListener("click",a=>{const s=a.target.closest("[data-gp-chat-action]");if(!s||!o)return;const l=s.dataset.gpChatAction;if(l==="remove")o.onRemove(),i();else if(l==="move"){const d=s.dataset.gpTargetProject;d&&(o.onMoveToProject(d),i())}}),document.addEventListener("click",a=>{t.contains(a.target)||i()}),document.addEventListener("keydown",a=>{a.key==="Escape"&&i()}),{open:r,close:i}}function vn(n){const e=document.createElement("div");e.className="gp-toast",n.appendChild(e);let t=null;function o(i){e.textContent=i,e.style.display="block",t&&window.clearTimeout(t),t=window.setTimeout(()=>{e.style.display="none"},2200)}function r(){e.style.display="none"}return{show:o,hide:r}}function yn(n,e){const o=Array.from(document.querySelectorAll('a[href*="/app/"]')).find(r=>r.href.includes(`/app/${n}`)?!!r.closest('nav, aside, [role="navigation"], [role="complementary"]'):!1);if(o){o.click();return}e&&window.location.assign(e)}function xn(n,e){const t=s=>s.getRootNode().host,o=t(n),r=t(e),i=()=>{const l=document.body.className.toLowerCase().includes("dark");o&&o.classList.toggle("dark",l),r&&r.classList.toggle("dark",l)};new MutationObserver(i).observe(document.body,{attributes:!0,attributeFilter:["class"]}),i()}const Re="data-gp-prompt-btn",wn="gp-prompt-btn",it=["mic","microphone","麦克风"],at=["fast","quick","快速"],kn=`
<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true">
  <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.89 2 1.99 2H15l6-6V5c0-1.1-.9-2-2-2ZM8 8h8c.55 0 1 .45 1 1s-.45 1-1 1H8c-.55 0-1-.45-1-1s.45-1 1-1Zm3 6H8c-.55 0-1-.45-1-1s.45-1 1-1h3c.55 0 1 .45 1 1s-.45 1-1 1Zm4 5.5V15h4.5L15 19.5Z"/>
</svg>
`;let Te=null,Be=null,xe=null;function Ct(...n){console.log("[GP Prompts]",...n)}function te(n){return(n||"").trim().toLowerCase()}function Et(n){if(!n||!document.body.contains(n)||n.hasAttribute(Re)||n.closest("#gp-prompt-picker-root"))return!1;const e=window.getComputedStyle(n);if(e.display==="none"||e.visibility==="hidden"||e.pointerEvents==="none")return!1;const t=n.getBoundingClientRect();return t.width>=18&&t.height>=18}function Cn(n){return te((n.getAttribute("aria-label")||"")+" "+(n.getAttribute("title")||"")+" "+(n.textContent||"").replace(/\s+/g," "))}function be(n,e){return e.some(t=>n.includes(te(t)))}function St(n){return te((n.textContent||"").replace(/\s+/g," "))}function En(n){return n.tagName.toLowerCase()==="button"||n.getAttribute("role")==="button"}function Sn(n){const e=n.getBoundingClientRect();return e.width>320||e.height>96}function Mn(n){const e=Cn(n),t=St(n),o=te(n.getAttribute("data-node-type")),r=te(n.tagName);return!!(be(e,it)||be(t,it)||be(e,at)||be(t,at)||o.includes("speech_dictation_mic")||r==="speech-dictation-mic-button"||n.closest("speech-dictation-mic-button"))}function Pn(n){const e=new Set,t=[];for(const o of n)e.has(o)||(e.add(o),t.push(o));return t}function In(){const n=['rich-textarea [contenteditable="true"]','div[contenteditable="true"][role="textbox"]',"textarea"];for(const e of n){const t=document.querySelector(e);if(Et(t))return t}return null}function Tn(n){return n.closest('input-area-v2, [data-node-type="input-area"], .input-area')||n.parentElement||n}function An(n){return!!n.closest('nav, aside, [role="navigation"], [role="complementary"]')}function Ln(n,e){const t=n.left>e.right?n.left-e.right:e.left>n.right?e.left-n.right:0,o=n.top>e.bottom?n.top-e.bottom:e.top>n.bottom?e.top-n.bottom:0;return{x:t,y:o}}function jn(n,e){const t=n.getBoundingClientRect(),o=e.getBoundingClientRect(),r=Ln(t,o);return r.y<=180&&r.x<=520}function Rn(n,e){const t=n.getBoundingClientRect(),o=e.getBoundingClientRect(),r=t.top+t.height/2,i=t.right>=o.left-40&&t.left<=o.right+40,a=r>=o.top-8&&r<=o.bottom+44,s=t.width<=320&&t.height<=96;return i&&a&&s}function Bn(n){const e=Tn(n),t=Array.from(e.querySelectorAll('button, [role="button"]')).map(i=>i.closest('button, [role="button"]')||i).filter(i=>En(i)&&Et(i)&&!Sn(i)&&!An(i)&&jn(i,n)&&Rn(i,n)&&!Mn(i)),o=Pn(t).filter(i=>{const a=te(i.getAttribute("aria-label")),s=St(i),l=te(i.className),d=a==="tools"||a==="工具"||l.includes("toolbox-drawer-button"),g=s==="tools"||s==="工具"||/\btools\b/.test(s)||s.includes("工具");return d||g});if(!o.length)return;const r=n.getBoundingClientRect();return[...o].sort((i,a)=>{const s=i.getBoundingClientRect(),l=a.getBoundingClientRect(),d=Math.abs(s.top+s.height/2-(r.bottom-22)),g=Math.abs(l.top+l.height/2-(r.bottom-22)),c=Math.abs(s.left-r.left),b=Math.abs(l.left-r.left),u=d*2+c,f=g*2+b;return u-f})[0]}function st(){var d,g;const n=((d=document.body)==null?void 0:d.className)||"",e=((g=document.documentElement)==null?void 0:g.className)||"",t=`${n} ${e}`;if(/\b(light|theme-light)\b/.test(t))return!1;if(/\b(dark|theme-dark|dark-theme)\b/.test(t))return!0;const o=[document.body,document.documentElement].map(c=>c?getComputedStyle(c).backgroundColor:"").find(c=>c&&c!=="transparent");if(!o)return!1;const r=o.match(/\d+(\.\d+)?/g);if(!r||r.length<3)return!1;const[i,a,s]=r.slice(0,3).map(Number);return(.2126*i+.7152*a+.0722*s)/255<.45}function Dn(n){xe=n,$n(),Mt()}function $n(){Te||(Te=new MutationObserver(n=>{n.some(t=>t.type==="childList"&&t.addedNodes.length>0)&&Mt()}),Te.observe(document.body,{childList:!0,subtree:!0}))}function Mt(){if(Be&&document.body.contains(Be))return;const n=In();if(!n)return;const e=Bn(n);if(!e)return;const t=e.parentElement;t&&(Ct("Found anchor:",e,"Container:",t),Nn(t,e))}function Nn(n,e){const t=e,r=(()=>{const h=Array.from(n.querySelectorAll('button, div[role="button"]')).filter(S=>S!==t&&!S.hasAttribute(Re)),p=h.filter(S=>/\bicon-button\b/.test(S.className)),x=p.length?p:h;if(!x.length)return t;const M=t.getBoundingClientRect();return x.sort((S,A)=>{const H=S.getBoundingClientRect(),R=A.getBoundingClientRect(),D=Math.abs(H.left-M.left),B=Math.abs(R.left-M.left);return D-B}),x[0]})(),i=document.createElement("button");i.type="button",i.id=wn,i.setAttribute(Re,"true"),i.setAttribute("aria-label","Prompts"),i.setAttribute("title","Prompts"),i.className="gp-prompt-btn",i.style.setProperty("display","flex","important"),i.style.setProperty("align-items","center","important"),i.style.setProperty("justify-content","center","important"),i.style.setProperty("margin","0","important"),i.style.setProperty("cursor","pointer","important"),i.style.setProperty("flex","0 0 auto","important"),i.style.setProperty("padding","0","important"),i.style.setProperty("gap","0","important");const a=window.getComputedStyle(r),s=Number.parseFloat(a.height||""),l=Number.isFinite(s)&&s>0?Math.max(36,Math.min(44,Math.round(s))):40,d=`${l}px`,g=`${l}px`;i.style.setProperty("width",d,"important"),i.style.setProperty("height",g,"important"),i.style.setProperty("min-width",d,"important"),i.style.setProperty("min-height",g,"important"),i.style.setProperty("max-width",d,"important"),i.style.setProperty("max-height",g,"important"),i.style.setProperty("border-radius","50%","important"),i.style.setProperty("border","none","important"),i.style.setProperty("background-color","transparent","important"),i.style.setProperty("transition","background-color 140ms ease","important"),i.style.setProperty("outline","none","important");const c=document.createElement("span");c.style.display="flex",c.style.alignItems="center",c.style.justifyContent="center",c.style.width="20px",c.style.height="20px",c.style.flex="0 0 20px",c.innerHTML=kn.trim();const b=c.querySelector("svg");b&&(b.setAttribute("width","20"),b.setAttribute("height","20")),i.appendChild(c),i.style.opacity="1";const u=st()?"rgba(255, 255, 255, 0.12)":"rgba(68, 71, 70, 0.08)",f=st()?"rgba(255, 255, 255, 0.16)":"rgba(68, 71, 70, 0.14)";i.addEventListener("mouseenter",()=>{i.style.setProperty("background-color",u,"important")}),i.addEventListener("mouseleave",()=>{i.style.setProperty("background-color","transparent","important")}),i.addEventListener("mousedown",()=>{i.style.setProperty("background-color",f,"important")}),i.addEventListener("mouseup",()=>{i.style.setProperty("background-color",u,"important")}),i.onclick=h=>{h.preventDefault(),h.stopPropagation(),xe==null||xe()},e.insertAdjacentElement("afterend",i),n.contains(i)||n.appendChild(i),Be=i,Ct("Injected button")}const On="modulepreload",qn=function(n){return"/"+n},lt={},Hn=function(e,t,o){let r=Promise.resolve();if(t&&t.length>0){document.getElementsByTagName("link");const a=document.querySelector("meta[property=csp-nonce]"),s=(a==null?void 0:a.nonce)||(a==null?void 0:a.getAttribute("nonce"));r=Promise.allSettled(t.map(l=>{if(l=qn(l),l in lt)return;lt[l]=!0;const d=l.endsWith(".css"),g=d?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${g}`))return;const c=document.createElement("link");if(c.rel=d?"stylesheet":On,d||(c.as="script"),c.crossOrigin="",c.href=l,s&&c.setAttribute("nonce",s),document.head.appendChild(c),d)return new Promise((b,u)=>{c.addEventListener("load",b),c.addEventListener("error",()=>u(new Error(`Unable to preload CSS for ${l}`)))})}))}function i(a){const s=new Event("vite:preloadError",{cancelable:!0});if(s.payload=a,window.dispatchEvent(s),!s.defaultPrevented)throw a}return r.then(a=>{for(const s of a||[])s.status==="rejected"&&i(s.reason);return e().catch(i)})};function ct(){return crypto.randomUUID()}const Pt=[{name:"gray",bg:"rgba(31,31,31,0.14)",fg:"#1f1f1f"},{name:"red",bg:"rgba(232,92,92,0.15)",fg:"#E85C5C"},{name:"orange",bg:"rgba(249,115,22,0.15)",fg:"#F97316"},{name:"yellow",bg:"rgba(245,158,11,0.15)",fg:"#F59E0B"},{name:"green",bg:"rgba(34,197,94,0.15)",fg:"#22C55E"},{name:"blue",bg:"rgba(59,130,246,0.15)",fg:"#3B82F6"},{name:"purple",bg:"rgba(139,92,246,0.15)",fg:"#8B5CF6"},{name:"pink",bg:"rgba(236,72,153,0.15)",fg:"#EC4899"}],ce="gp_prompts_store",dt=new Set(Pt.map(n=>n.name)),Fn={prompts:{},tagMeta:{},version:1},zn=[{title:"Summarize",content:"Please summarize the following text into bullet points, capturing the key insights and main arguments:",tags:["writing","summary"]},{title:"Code Review",content:"Review the following code for bugs, performance issues, and best practices. Suggest improvements with code examples:",tags:["coding","review"]},{title:"Bug Fix",content:'I am encountering a bug. Here is the error message: "{{error}}". Here is the relevant code snippet: "{{code}}". Please analyze the root cause and provide a fix.',tags:["coding","debug"]},{title:"Email Polish",content:"Rewrite the following email to be more professional and concise, while maintaining a friendly tone:",tags:["writing","email"]}];function _n(n){return n.replace(/&lt;/gi,"<").replace(/&gt;/gi,">").replace(/&nbsp;/gi," ").replace(/&amp;/gi,"&").replace(/&quot;/gi,'"').replace(/&#39;/gi,"'")}function z(n){if(!n)return"";let e=_n(n).trim();return e=e.replace(/<\s*span\s*>/gi," ").replace(/<\s*\/\s*span\s*>/gi," ").replace(/<\s*span[^>]*>/gi," ").replace(/<\/\s*span\s*>/gi," ").replace(/\s+/g," ").trim(),e}function Ae(n){if(!Array.isArray(n))return[];const e=[],t=new Set;return n.forEach(o=>{const r=z(typeof o=="string"?o:String(o||""));!r||t.has(r)||(t.add(r),e.push(r))}),e}function Un(n,e){if(n.length!==e.length)return!1;for(let t=0;t<n.length;t++)if(n[t]!==e[t])return!1;return!0}class Gn{constructor(){E(this,"cache",null);E(this,"listeners",new Set);this.refresh(),chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&e[ce]&&(this.cache=e[ce].newValue,this.notify())})}async loadFromStorage(){return new Promise(e=>{chrome.storage.local.get([ce],t=>{let o=t[ce];if(!o)o=this.seed(Fn),this.saveToStorage(o);else{let r=!1;(!o.prompts||typeof o.prompts!="object")&&(o.prompts={},r=!0),(!o.tagMeta||typeof o.tagMeta!="object")&&(o.tagMeta={},r=!0),Object.values(o.prompts).forEach(a=>{const s=Array.isArray(a.tags)?a.tags:[],l=Ae(s);Un(s,l)||(a.tags=l,r=!0)});const i={};Object.entries(o.tagMeta).forEach(([a,s])=>{const l=z(a);if(!l){r=!0;return}const d=s&&typeof s.color=="string"&&dt.has(s.color)?s.color:"gray",g=i[l];g?(g.color==="gray"&&d!=="gray"&&(g.color=d),r=!0):i[l]={name:l,color:d},(l!==a||!s||s.name!==l||!(s&&typeof s.color=="string"&&dt.has(s.color)))&&(r=!0)}),Object.values(o.prompts).forEach(a=>{a.tags.forEach(s=>{i[s]||(i[s]={name:s,color:"gray"},r=!0)})}),o.tagMeta=i,r&&this.saveToStorage(o)}e(o)})})}seed(e){if(Object.keys(e.prompts).length===0){const t=Date.now();zn.forEach(o=>{const r=ct();e.prompts[r]={id:r,title:o.title||"Untitled",content:o.content||"",tags:o.tags||[],createdAt:t,updatedAt:t,usageCount:0,lastUsedAt:0,isFavorite:!1}})}return e}saveToStorage(e){chrome.storage.local.set({[ce]:e})}async refresh(){this.cache=await this.loadFromStorage(),this.notify()}getAll(){return this.cache?Object.values(this.cache.prompts).sort((e,t)=>e.isFavorite!==t.isFavorite?t.isFavorite?1:-1:t.lastUsedAt!==e.lastUsedAt?t.lastUsedAt-e.lastUsedAt:0):[]}get(e){var t;return(t=this.cache)==null?void 0:t.prompts[e]}async save(e){this.cache||await this.refresh();const t=this.cache,o=Date.now(),r=Ae(e.tags||[]);let i;e.id&&t.prompts[e.id]?i={...t.prompts[e.id],...e,tags:r,updatedAt:o}:i={id:ct(),title:e.title,content:e.content,tags:r,createdAt:o,updatedAt:o,usageCount:0,lastUsedAt:0,isFavorite:e.isFavorite||!1},t.prompts[i.id]=i,t.tagMeta||(t.tagMeta={}),r.forEach(a=>{t.tagMeta[a]||(t.tagMeta[a]={name:a,color:"gray"})}),this.saveToStorage(t)}async delete(e){this.cache||await this.refresh();const t=this.cache;t.prompts[e]&&(delete t.prompts[e],this.saveToStorage(t))}async trackUsage(e){this.cache||await this.refresh();const t=this.cache;t.prompts[e]&&(t.prompts[e].usageCount++,t.prompts[e].lastUsedAt=Date.now(),this.saveToStorage(t))}async toggleFavorite(e){this.cache||await this.refresh();const t=this.cache;t.prompts[e]&&(t.prompts[e].isFavorite=!t.prompts[e].isFavorite,this.saveToStorage(t))}subscribe(e){return this.listeners.add(e),()=>this.listeners.delete(e)}notify(){this.listeners.forEach(e=>e())}getAllTags(){if(!this.cache)return[];const e={};Object.values(this.cache.prompts).forEach(o=>{o.tags.forEach(r=>e[r]=(e[r]||0)+1)});const t=this.cache.tagMeta||{};return Object.keys(t).forEach(o=>{e[o]===void 0&&(e[o]=0)}),Object.entries(e).map(([o,r])=>{var i;return{name:o,count:r,color:((i=t[o])==null?void 0:i.color)||this.getRandomColor()}}).sort((o,r)=>r.count-o.count)}getTagColor(e){var o,r;const t=z(e);return t&&((r=(o=this.cache)==null?void 0:o.tagMeta[t])==null?void 0:r.color)||"gray"}getRandomColor(){const e=Pt.map(t=>t.name);return e[Math.floor(Math.random()*e.length)]}async ensureTagColor(e){const t=z(e);if(!t)return"gray";this.cache||await this.refresh();const o=this.cache;if(o.tagMeta||(o.tagMeta={}),!o.tagMeta[t]){const r=this.getRandomColor();return o.tagMeta[t]={name:t,color:r},this.saveToStorage(o),r}return o.tagMeta[t].color}async setTagColor(e,t){const o=z(e);if(!o)return;this.cache||await this.refresh();const r=this.cache;r.tagMeta||(r.tagMeta={}),r.tagMeta[o]={name:o,color:t},this.saveToStorage(r)}async renameTag(e,t){const o=z(e),r=z(t);if(!o||!r||o===r)return;this.cache||await this.refresh();const i=this.cache;if(Object.values(i.prompts).forEach(a=>{a.tags=Ae(a.tags.map(s=>s===o?r:s))}),i.tagMeta||(i.tagMeta={}),i.tagMeta[o]){const a=i.tagMeta[o].color;i.tagMeta[r]||(i.tagMeta[r]={name:r,color:a}),delete i.tagMeta[o]}else i.tagMeta[r]||(i.tagMeta[r]={name:r,color:"gray"});this.saveToStorage(i),this.notify()}async deleteTagGlobal(e){const t=z(e);if(!t)return;this.cache||await this.refresh();const o=this.cache;Object.values(o.prompts).forEach(r=>{r.tags=r.tags.filter(i=>i!==t)}),o.tagMeta&&delete o.tagMeta[t],this.saveToStorage(o),this.notify()}}const F=new Gn,De="gemini_projects_v1",$e="gp_prompts_store",It=1;function Vn(){const n=new Date,e=n.getFullYear(),t=String(n.getMonth()+1).padStart(2,"0"),o=String(n.getDate()).padStart(2,"0");return`gemini-projects-backup-${e}-${t}-${o}.json`}async function Wn(){const n=await chrome.storage.local.get([De,$e]),e={version:It,exportedAt:new Date().toISOString(),projects:n[De]??null,prompts:n[$e]??null},t=new Blob([JSON.stringify(e,null,2)],{type:"application/json"}),o=URL.createObjectURL(t),r=document.createElement("a");r.href=o,r.download=Vn(),document.body.appendChild(r),r.click(),document.body.removeChild(r),URL.revokeObjectURL(o)}function Zn(n){const e=JSON.parse(n);return!e||typeof e!="object"||typeof e.version!="number"||e.version>It?null:e}async function Kn(n){try{const e=await n.text(),t=Zn(e);if(!t)return{success:!1,message:"Invalid backup file format."};const o={};return t.projects!==null&&t.projects!==void 0&&(o[De]=t.projects),t.prompts!==null&&t.prompts!==void 0&&(o[$e]=t.prompts),Object.keys(o).length?(await chrome.storage.local.set(o),{success:!0,message:t.exportedAt?`Restore completed. Backup timestamp: ${t.exportedAt}`:"Restore completed."}):{success:!1,message:"No restorable data found in backup file."}}catch(e){return console.error("[Backup] import failed",e),{success:!1,message:"Failed to read or parse the backup file."}}}function Yn(n){const e=document.createElement("input");e.type="file",e.accept=".json,application/json",e.onchange=async()=>{var r;const t=(r=e.files)==null?void 0:r[0];if(!t)return;const o=await Kn(t);n==null||n(o)},e.click()}const Qn="gp-prompt-picker-root",de={search:'<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path fill-rule="evenodd" d="M10.5 3a7.5 7.5 0 0 1 5.92 12.1l4.24 4.24-1.42 1.42-4.24-4.24A7.5 7.5 0 1 1 10.5 3Zm0 2a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11Z" clip-rule="evenodd"/></svg>',plus:'<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 5v14"/><path d="M5 12h14"/></svg>',close:'<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="m6.34 4.93-1.41 1.41L10.59 12l-5.66 5.66 1.41 1.41L12 13.41l5.66 5.66 1.41-1.41L13.41 12l5.66-5.66-1.41-1.41L12 10.59 6.34 4.93Z"/></svg>',edit:'<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M3 17.25V21h3.75l11.06-11.06-3.75-3.75L3 17.25Zm2.92 2.33H5v-1.17l8.06-8.06 1.17 1.17-8.31 8.06ZM20.71 7.04a1 1 0 0 0 0-1.41L18.37 3.29a1 1 0 0 0-1.41 0L15.13 5.12l3.75 3.75 1.83-1.83Z"/></svg>'},K=class K{constructor(){E(this,"shadow");E(this,"host");E(this,"isOpen",!1);E(this,"searchQuery","");E(this,"triggerRect",null);E(this,"selectedPromptId",null);E(this,"visiblePromptIds",[]);E(this,"lastVisibleCount",0);E(this,"pendingDeletePromptId",null);E(this,"inlineEditDraft",null);E(this,"themeObserver",null);E(this,"modalDeleteConfirm",!1);E(this,"modalDeleteTimer",null);E(this,"editingPrompt",null);this.host=document.createElement("div"),this.host.id=Qn,this.host.style.position="fixed",this.host.style.zIndex="2147483647",this.host.style.display="none",this.host.style.pointerEvents="none",document.body.appendChild(this.host),this.shadow=this.host.attachShadow({mode:"open"}),this.render(),this.syncTheme(),this.startThemeObserver(),F.subscribe(()=>this.updateList()),document.addEventListener("mousedown",e=>{if(this.isOpen&&!e.composedPath().includes(this.host)&&!e.target.closest("[data-gp-prompt-btn]")){const r=this.shadow.querySelector(".modal-overlay");if(r&&r.style.display!=="none")return;this.close()}},!0),document.addEventListener("keydown",e=>{if(!this.isOpen)return;const t=this.shadow.querySelector(".modal-overlay"),o=!!t&&t.style.display!=="none";if(e.key==="Escape"){o?this.closeModal():this.close();return}if(!o){if(e.key==="ArrowDown"){e.preventDefault(),this.moveSelection(1);return}if(e.key==="ArrowUp"){e.preventDefault(),this.moveSelection(-1);return}if(e.key==="Enter"){const r=document.activeElement;if(r&&(r.tagName==="TEXTAREA"||r.tagName==="INPUT")&&!r.classList.contains("search-input"))return;e.preventDefault(),this.insertSelectedPrompt(e.ctrlKey||e.metaKey)}}}),window.addEventListener("resize",()=>{this.isOpen&&(this.updatePosition(),this.applyDynamicHeight(this.lastVisibleCount))})}static getInstance(){return K.instance||(K.instance=new K),K.instance}toggle(e){this.isOpen?this.close():this.open(e)}open(e){this.syncTheme(),this.isOpen=!0,this.triggerRect=e,this.selectedPromptId=null,this.pendingDeletePromptId=null,this.visiblePromptIds=[],this.inlineEditDraft=null,this.searchQuery="",this.host.style.display="block",this.host.style.pointerEvents="auto";const t=this.shadow.querySelector(".picker");t&&(t.offsetWidth,t.classList.add("open")),this.updatePosition(),this.updateList();const o=this.shadow.querySelector(".search-input");o&&(o.value="",setTimeout(()=>o.focus(),10))}close(){this.isOpen=!1,this.pendingDeletePromptId=null,this.inlineEditDraft=null;const e=this.shadow.querySelector(".picker");e&&e.classList.remove("open"),setTimeout(()=>{this.isOpen||(this.host.style.display="none",this.host.style.pointerEvents="none")},200)}updatePosition(){if(!this.triggerRect)return;const e=12,t=12,o=window.innerWidth,r=window.innerHeight,i=o<=720,a=this.shadow.querySelector(".picker"),s=Math.min(i?o-e*2:440,o-e*2),l=Math.min(i?r-96:520,r-e*2);a&&(a.style.width=`${Math.max(280,s)}px`,a.style.height=`${Math.max(220,l)}px`,a.style.maxHeight=`${Math.max(220,l)}px`);let d=this.triggerRect.left,g=this.triggerRect.bottom+t,c="none";if(i)d=e,g=r-l-16;else{const b=this.triggerRect.right+t,u=this.triggerRect.left-s-t,f=b+s<=o-e,h=u>=e;if(f)d=b,c="left";else if(h)d=u,c="right";else{const x=this.triggerRect.left+this.triggerRect.width/2-s/2;d=Math.max(e,Math.min(x,o-s-e)),c="none"}const p=this.triggerRect.top-12;g=Math.max(e,Math.min(p,r-l-e))}if(d+s>o-e&&(d=o-s-e),d<e&&(d=e),g<e&&(g=e),this.host.style.left=`${Math.round(d)}px`,this.host.style.top=`${Math.round(g)}px`,a){a.classList.remove("anchor-left","anchor-right","anchor-none"),a.classList.add(c==="left"?"anchor-left":c==="right"?"anchor-right":"anchor-none");const b=Math.max(28,Math.min(this.triggerRect.top+this.triggerRect.height/2-g,l-28));a.style.setProperty("--gp-pointer-top",`${Math.round(b)}px`)}}applyDynamicHeight(e){const t=this.shadow.querySelector(".picker"),o=this.shadow.getElementById("list-container");if(!t||!o)return;const r=t.querySelector(".header"),i=t.querySelector(".footer-action"),a=(r==null?void 0:r.offsetHeight)||74,s=i?getComputedStyle(i).position==="absolute"?76:i.offsetHeight:0,l=o.querySelector(".item"),d=l?l.offsetHeight+(parseFloat(getComputedStyle(l).marginBottom)||0):96,g=e<=0?1:2.5,c=e<=0?104:Math.max(228,d*g+8),b=Math.min(window.innerHeight-24,620),u=a+s+104,f=Math.max(u,Math.min(a+s+c,b));t.style.height=`${Math.round(f)}px`,t.style.maxHeight=`${Math.round(b)}px`}startThemeObserver(){this.themeObserver||(this.themeObserver=new MutationObserver(()=>this.syncTheme()),this.themeObserver.observe(document.documentElement,{attributes:!0,attributeFilter:["class","style","data-theme"]}),document.body&&this.themeObserver.observe(document.body,{attributes:!0,attributeFilter:["class","style","data-theme"]}))}syncTheme(){this.host.dataset.gpTheme=this.resolveTheme()}resolveTheme(){const e=document.documentElement,t=document.body,o=`${e.className} ${(t==null?void 0:t.className)||""}`.toLowerCase();if(/\b(light|theme-light)\b/.test(o))return"light";if(/\b(dark|theme-dark|dark-theme)\b/.test(o))return"dark";const r=[t,e].map(g=>g?getComputedStyle(g).backgroundColor:"").find(g=>g&&g!=="transparent");if(!r)return"light";const i=r.match(/\d+(\.\d+)?/g);if(!i||i.length<3)return"light";const[a,s,l]=i.slice(0,3).map(Number);return(.2126*a+.7152*s+.0722*l)/255<.45?"dark":"light"}getStyles(){return`
      @import url('https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;500;600&family=Noto+Serif+SC:wght@400;500;600;700&display=swap');
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
      @font-face {
        font-family: 'GP Styrene';
        src: local('Styrene A'), local('Styrene B'), local('Styrene A Web'), local('Styrene B Web'), local('Styrene');
        font-weight: 100 900;
        font-style: normal;
        font-display: swap;
      }
      @font-face {
        font-family: 'GP Tiempos';
        src: local('Tiempos Text'), local('Tiempos Headline'), local('Tiempos');
        font-weight: 100 900;
        font-style: normal;
        font-display: swap;
      }
      @font-face {
        font-family: 'Anthropic Serif Web Text';
        src: local('Anthropic Serif Web Text'), local('Anthropic Serif Text'), local('Anthropic Serif');
        font-weight: 100 900;
        font-style: normal;
        font-display: swap;
      }

      :host {
        /* Core Palette - Strictly defined, no OS overrides */
        --gp-font-sans: 'GP Styrene', 'Styrene A', 'Styrene B', 'Styrene', 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        --gp-font-serif: 'GP Tiempos', 'Tiempos Text', 'Tiempos Headline', 'Tiempos', 'Anthropic Serif Web Text', 'Anthropic Serif Text', 'Anthropic Serif', 'Source Serif 4', 'Noto Serif SC', 'Songti SC', 'SimSun', 'Georgia', serif; 
        
        /* Anthropic-inspired palette */
        --gp-surface: #ede9e0;
        --gp-surface-elevated: #f5f2ea;
        --gp-ink: #1b1a18;
        --gp-stone: #a4a19b;
        --gp-slate: #5b5954;
        --gp-muted: #838079;
        --gp-coral: #d97c5d;

        /* Light Mode Defaults */
        --gp-bg-glass: rgba(237, 233, 224, 0.94);
        --gp-fg: var(--gp-ink);
        --gp-fg-secondary: var(--gp-slate);
        --gp-fg-tertiary: var(--gp-muted);
        --gp-border: rgba(91, 89, 84, 0.24);
        --gp-bg-hover: rgba(91, 89, 84, 0.08);
        --gp-bg-active: rgba(91, 89, 84, 0.14);
        --gp-shadow-sm: 0 4px 12px rgba(27, 26, 24, 0.08);
        --gp-shadow-lg: 0 24px 48px -14px rgba(27, 26, 24, 0.22), 0 0 1px rgba(27, 26, 24, 0.18);
        --gp-danger: #b85a3e;
        --gp-accent: var(--gp-ink);
        --gp-accent-fg: var(--gp-surface);
        --gp-focus: var(--gp-coral);
        --gp-radius-lg: 16px;
        --gp-radius-md: 10px;
        --gp-radius-sm: 6px;
      }

      /* Dark Mode - Explicit Data Attribute Strategy */
      :host([data-gp-theme="dark"]) {
        --gp-bg-glass: rgba(27, 26, 24, 0.94);
        --gp-fg: #ede9e0;
        --gp-fg-secondary: #c9c5bc;
        --gp-fg-tertiary: #a4a19b;
        --gp-border: rgba(237, 233, 224, 0.16);
        --gp-bg-hover: rgba(237, 233, 224, 0.08);
        --gp-bg-active: rgba(237, 233, 224, 0.14);
        --gp-shadow-sm: 0 4px 12px rgba(0, 0, 0, 0.32);
        --gp-shadow-lg: 0 26px 52px -12px rgba(0, 0, 0, 0.52), 0 0 1px rgba(237, 233, 224, 0.2);
        --gp-danger: #ff8b67;
        --gp-accent: #ede9e0;
        --gp-accent-fg: #1b1a18;
        --gp-focus: #d97c5d;
      }

      * { box-sizing: border-box; outline: none; }

      /* === MAIN CONTAINER === */
      .picker {
        position: relative;
        width: 400px; /* Slightly wider for breathing room */
        max-height: 600px;
        background: var(--gp-bg-glass);
        backdrop-filter: blur(24px) saturate(180%);
        -webkit-backdrop-filter: blur(24px) saturate(180%);
        border: 1px solid var(--gp-border);
        border-radius: var(--gp-radius-lg);
        box-shadow: var(--gp-shadow-lg);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        font-family: var(--gp-font-sans);
        color: var(--gp-fg);
        z-index: 99999;
        
        /* Animation States */
        opacity: 0;
        transform: translateY(12px) scale(0.96);
        transition: opacity 0.25s cubic-bezier(0.16, 1, 0.3, 1), 
                    transform 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        pointer-events: none;
      }

      .picker.open {
        opacity: 1;
        transform: translateY(0) scale(1);
        pointer-events: auto;
      }

      /* === HEADER === */
      .header {
        padding: 16px 16px 8px; /* Breathing room */
        flex-shrink: 0;
      }

      .search-row {
        position: relative;
        background: rgba(91, 89, 84, 0.09);
        border-radius: 99px;
        transition: box-shadow 0.2s, background 0.2s;
        border: 1px solid transparent;
      }
      .search-row:focus-within {
        background: var(--gp-surface-elevated);
        box-shadow: 0 0 0 2px var(--gp-focus);
      }

      .search-box {
        display: flex;
        align-items: center;
        height: 38px;
        padding: 0 12px;
      }

      .search-icon {
        color: var(--gp-fg-secondary);
        opacity: 0.7;
        margin-right: 8px;
        display: flex; /* Fix icon alignment */
      }

      .search-input {
        flex: 1;
        background: transparent;
        border: none;
        color: var(--gp-fg);
        font-family: var(--gp-font-sans); /* Use Sans for inputs */
        font-size: 14px;
        font-weight: 500;
        padding: 0;
      }
      .search-input::placeholder {
        color: var(--gp-fg-tertiary);
        font-weight: 400;
      }

      /* === TAGS AREA === */
      .tags-area {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        padding: 12px 16px 4px;
        margin: 0; /* Reset margins */
      }
      .tag {
        font-family: var(--gp-font-sans);
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 0.01em;
        background: var(--gp-bg-hover);
        color: var(--gp-fg-secondary);
        padding: 4px 10px;
        border-radius: 99px;
        border: 1px solid transparent; /* Prepare for border transition */
        transition: all 0.15s ease;
      }
      .tag:hover {
        background: var(--gp-bg-active);
        transform: translateY(-1px);
        color: var(--gp-fg);
      }
      .tag.active {
        background: var(--gp-accent);
        color: var(--gp-accent-fg);
        box-shadow: 0 2px 8px rgba(0,0,0,0.15);
      }

      /* === LIST === */
      .list {
        flex: 1;
        overflow-y: auto;
        overscroll-behavior: contain;
        padding: 8px 12px 84px;
      }
      .list::-webkit-scrollbar {
        width: 8px;
      }
      .list::-webkit-scrollbar-thumb {
        background: rgba(131, 128, 121, 0.7);
        border-radius: 999px;
      }
      
      .empty-box {
        margin-top: 60px;
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        gap: 12px;
        color: var(--gp-fg-tertiary);
        opacity: 0.8;
      }
      .empty-box::before {
        content: 'No prompts';
        font-family: var(--gp-font-serif);
        font-size: 20px;
        font-weight: 500;
        color: var(--gp-fg-secondary);
      }

      /* === LIST ITEM === */
      .item {
        position: relative;
        padding: 14px 16px;
        margin-bottom: 4px;
        border-radius: var(--gp-radius-md);
        cursor: pointer;
        border: 1px solid transparent;
        transition: transform 0.16s cubic-bezier(0.16, 1, 0.3, 1), background 0.16s ease, border-color 0.16s ease;
      }
      .item::before {
        content: '';
        position: absolute;
        left: 0;
        top: 10px;
        bottom: 10px;
        width: 3px;
        border-radius: 0 4px 4px 0;
        background: var(--gp-accent);
        opacity: 0;
        transform: scaleY(0.65);
        transform-origin: center;
        transition: opacity 0.16s ease, transform 0.16s ease;
      }
      .item:hover {
        background: transparent;
        border-color: transparent;
        transform: translateX(3px);
      }
      .item.selected {
        background: transparent;
        border-color: transparent;
        transform: translateX(2px);
      }
      .item:hover::before,
      .item.selected::before {
        opacity: 1;
        transform: scaleY(1);
      }
      .item-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 4px;
        padding-right: 60px; /* Space for actions */
      }

      .item-title {
        font-family: var(--gp-font-serif);
        font-size: 16px;
        font-weight: 600;
        color: var(--gp-fg);
        line-height: 1.4;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .item-preview {
        font-family: var(--gp-font-sans);
        font-size: 13px;
        color: var(--gp-fg-secondary);
        line-height: 1.5;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }
      .item-content {
        min-width: 0;
        padding-right: 88px;
      }
      .item-head {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 4px;
      }

      /* === ITEM ACTIONS === */
      .item-actions {
        position: absolute;
        top: 12px;
        right: 12px;
        display: flex;
        gap: 4px;
        opacity: 0;
        transform: translateX(10px);
        transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        z-index: 10;
        /* No background! */
      }
      
      .item:hover .item-actions,
      .item.selected .item-actions,
      .item.editing .item-actions {
        opacity: 1;
        transform: translateX(0);
      }

      .item-action-btn {
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        border: none;
        background: var(--gp-surface-elevated);
        backdrop-filter: blur(4px);
        box-shadow: 0 2px 8px rgba(27, 26, 24, 0.12);
        color: var(--gp-fg-secondary);
        cursor: pointer;
        transition: all 0.15s;
        padding: 0;
      }
      .item-action-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(27, 26, 24, 0.18);
        color: var(--gp-fg);
        background: var(--gp-surface);
      }
      .item-action-btn.danger:hover {
        color: var(--gp-danger);
      }

      /* Delete Confirmation Inline */
      .delete-inline {
        display: flex;
        gap: 8px;
        align-items: center;
        background: rgba(131, 128, 121, 0.18);
        padding: 4px 6px;
        border-radius: 10px;
        box-shadow: var(--gp-shadow-sm);
        animation: slideIn 0.14s ease-out forwards;
      }
      @keyframes slideIn { from { opacity: 0; transform: translateX(10px); } to { opacity: 1; transform: translateX(0); } }

      .delete-inline-btn {
        height: 28px;
        padding: 0 12px;
        border-radius: 6px;
        border: none;
        font-family: var(--gp-font-sans);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 4px;
        color: var(--gp-fg);
        background: transparent;
      }
      .delete-inline-btn.confirm {
        background: var(--gp-danger);
        color: white;
        box-shadow: 0 2px 4px rgba(217, 48, 37, 0.3);
      }
      .delete-inline-btn.confirm:hover { box-shadow: 0 3px 8px rgba(217, 48, 37, 0.4); transform: translateY(-1px); }
      .delete-inline-btn:hover {
        background: var(--gp-bg-hover);
      }

      /* === INLINE EDITOR === */
      .inline-editor {
        display: flex;
        flex-direction: column;
        gap: 10px;
      }
      .inline-editor-row {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .inline-editor-label {
        font-family: var(--gp-font-sans);
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        color: var(--gp-fg-secondary);
      }
      .inline-editor-input,
      .inline-editor-textarea {
        width: 100%;
        border: 1px solid var(--gp-border);
        border-radius: 10px;
        background: var(--gp-bg-hover);
        color: var(--gp-fg);
        font-family: var(--gp-font-sans);
        font-size: 13px;
        padding: 10px 12px;
      }
      .inline-editor-input:focus,
      .inline-editor-textarea:focus {
        border-color: rgba(217, 124, 93, 0.7);
        background: rgba(237, 233, 224, 0.78);
      }
      .inline-editor-textarea {
        min-height: 108px;
        line-height: 1.45;
        resize: vertical;
        max-height: 260px;
      }
      .inline-editor-actions {
        display: flex;
        justify-content: flex-end;
        gap: 8px;
      }
      .inline-editor-btn {
        height: 32px;
        border-radius: 999px;
        border: 1px solid var(--gp-border);
        background: transparent;
        color: var(--gp-fg);
        font-family: var(--gp-font-sans);
        font-size: 13px;
        padding: 0 14px;
        cursor: pointer;
      }
      .inline-editor-btn:hover {
        background: var(--gp-bg-hover);
      }
      .inline-editor-btn.primary {
        border: none;
        background: var(--gp-accent);
        color: var(--gp-accent-fg);
      }

      /* === FLOATING ACTION === */
      .footer-action {
        position: absolute;
        right: 12px;
        bottom: 12px;
        z-index: 8;
        pointer-events: none;
      }
      .footer-buttons {
        display: flex;
        align-items: center;
        gap: 8px;
        pointer-events: auto;
      }
      .btn-utility {
        height: 36px;
        border-radius: 999px;
        border: 1px solid var(--gp-border);
        background: var(--gp-bg-glass);
        color: var(--gp-fg);
        font-family: var(--gp-font-sans);
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 0.01em;
        padding: 0 12px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        box-shadow: var(--gp-shadow-sm);
        transition: background 0.15s ease, transform 0.15s ease;
      }
      .btn-utility:hover {
        background: var(--gp-bg-hover);
        transform: translateY(-1px);
      }
      .btn-new {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: var(--gp-accent);
        color: var(--gp-accent-fg);
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        pointer-events: auto;
        box-shadow: 0 10px 20px -12px rgba(27, 26, 24, 0.45);
        transition: transform 0.15s ease, filter 0.15s ease;
      }
      .btn-new:hover {
        transform: translateY(-1px);
        filter: brightness(1.03);
      }
      .btn-new:active { transform: scale(0.96); }
      .btn-new span {
        display: none;
      }
      .btn-new svg { width: 16px; height: 16px; }

      /* === MODAL (EDIT/CREATE) === */
      .modal-overlay {
        position: fixed;
        inset: 0;
        background: rgba(27, 26, 24, 0.26);
        z-index: 2147483647;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 16px;
        backdrop-filter: blur(6px);
        -webkit-backdrop-filter: blur(6px);
        animation: modalFadeIn 0.25s ease-out;
      }
      @keyframes modalFadeIn { from { opacity: 0; transform: scale(0.98); } to { opacity: 1; transform: scale(1); } }
      .modal {
        width: min(860px, calc(100vw - 32px));
        height: min(66vh, 580px);
        min-height: min(410px, calc(100vh - 32px));
        background: rgba(245, 242, 234, 0.98);
        border: 1px solid var(--gp-border);
        border-radius: 12px;
        box-shadow: 0 12px 28px rgba(27, 26, 24, 0.2);
        overflow: hidden;
        display: flex;
        flex-direction: column;
      }
      :host([data-gp-theme="dark"]) .modal {
        background: rgba(35, 33, 30, 0.98);
        border-color: var(--gp-border);
        box-shadow: 0 12px 28px rgba(0, 0, 0, 0.45);
      }

      .modal-header {
        padding: 6px 14px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid var(--gp-border);
      }
      :host([data-gp-theme="dark"]) .modal-header {
        border-bottom-color: var(--gp-border);
      }
      .modal-title {
        font-family: var(--gp-font-serif);
        font-size: 16px;
        font-weight: 600;
        color: var(--gp-fg);
      }
      .modal-close {
        background: transparent;
        border: none;
        color: var(--gp-fg-secondary);
        cursor: pointer;
        padding: 4px;
        border-radius: 6px;
        transition: background 0.15s ease;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .modal-close:hover { background: var(--gp-bg-hover); color: var(--gp-fg); }

      .modal-body {
        padding: 10px 14px 10px;
        flex: 1;
        min-height: 0;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 12px;
      }

      /* Form Elements */
      .form-group { display: flex; flex-direction: column; gap: 10px; }
      .form-group.content-group { flex: 1; min-height: 150px; }
      .form-label {
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.045em;
        color: var(--gp-fg-secondary);
        font-family: var(--gp-font-sans);
      }

      .form-input, .form-textarea {
        background: rgba(237, 233, 224, 0.88);
        border: 1px solid var(--gp-border);
        border-radius: 8px;
        padding: 11px 14px;
        font-size: 16px;
        color: var(--gp-fg);
        width: 100%;
        transition: border-color 0.15s ease, box-shadow 0.15s ease;
      }
      .form-input {
        font-family: var(--gp-font-serif);
        font-weight: 500;
      }
      .form-textarea {
        font-family: var(--gp-font-serif);
      }
      :host([data-gp-theme="dark"]) .form-input,
      :host([data-gp-theme="dark"]) .form-textarea {
        background: rgba(28, 28, 28, 0.92);
        border-color: rgba(255, 255, 255, 0.15);
      }
      .form-input:focus, .form-textarea:focus {
        border-color: rgba(217, 124, 93, 0.7);
        box-shadow: none;
        outline: none;
      }
      .form-input::placeholder, .form-textarea::placeholder {
        color: var(--gp-fg-tertiary);
        font-style: normal;
      }
      .form-input {
        border-color: rgba(91, 89, 84, 0.18);
      }
      .form-textarea {
        border-color: rgba(91, 89, 84, 0.3);
      }
      .form-textarea {
        flex: 1;
        min-height: 160px;
        height: 100%;
        resize: none;
        line-height: 1.55;
        padding-bottom: 34px;
      }
      .textarea-shell {
        position: relative;
        flex: 1;
        min-height: 0;
      }
      .textarea-token {
        position: absolute;
        right: 12px;
        bottom: 12px;
        font-family: var(--gp-font-sans);
        font-size: 12px;
        line-height: 1;
        color: var(--gp-fg-secondary);
        pointer-events: none;
        user-select: none;
      }

      .modal-footer {
        padding: 8px 14px 10px;
        border-top: 1px solid var(--gp-border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        flex-shrink: 0;
        background: transparent;
      }
      :host([data-gp-theme="dark"]) .modal-footer {
        border-top-color: var(--gp-border);
      }
      .modal-footer-left,
      .modal-footer-right {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .modal-footer-right {
        margin-left: auto;
      }

      .btn {
        height: 36px;
        padding: 0 14px;
        border-radius: 6px;
        font-family: var(--gp-font-sans);
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.15s ease, border-color 0.15s ease, color 0.15s ease;
      }
      .btn-cancel {
        background: rgba(91, 89, 84, 0.06);
        border: 1px solid rgba(91, 89, 84, 0.28);
        color: var(--gp-fg);
      }
      .btn-cancel:hover {
        background: rgba(91, 89, 84, 0.12);
        border-color: rgba(91, 89, 84, 0.4);
      }

      .btn-delete {
        border: 1px solid transparent;
        color: rgba(190, 24, 24, 0.8);
        background: transparent;
        font-weight: 500;
      }
      .btn-delete:hover {
        background: rgba(217, 48, 37, 0.06);
        border-color: rgba(217, 48, 37, 0.24);
      }
      .btn-delete.confirming {
        background: rgba(217, 48, 37, 0.1);
        color: #b42318;
        border-color: rgba(217, 48, 37, 0.4);
      }
      
      .btn-save {
        background: var(--gp-accent);
        color: var(--gp-accent-fg);
        border: 1px solid var(--gp-accent);
      }
      .btn-save:hover { filter: brightness(1.06); }
      .btn-save:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }
    `}render(){var o,r,i;this.shadow.innerHTML=`
      <style>${this.getStyles()}</style>
      <div class="picker">
        <div class="header">
          <div class="search-row">
            <div class="search-box">
              <span class="search-icon">${de.search}</span>
              <input class="search-input" type="text" placeholder="Search prompts..." />
            </div>
          </div>
        </div>
        <div class="list" id="list-container"></div>
        <div class="footer-action">
          <div class="footer-buttons">
            <button class="btn-utility" id="btn-backup" title="Backup to local file">Backup</button>
            <button class="btn-utility" id="btn-restore" title="Restore from backup file">Restore</button>
            <button class="btn-new" id="btn-primary-action" title="New Prompt">
              ${de.plus} <span>New Prompt</span>
            </button>
          </div>
        </div>
      </div>
      <div class="modal-overlay" id="modal-overlay" style="display:none;"></div>
    `;const e=this.shadow.querySelector(".search-input");e==null||e.addEventListener("input",a=>{this.searchQuery=a.target.value.toLowerCase(),this.updateList()});const t=this.shadow.querySelector(".header");t==null||t.addEventListener("mousedown",a=>a.stopPropagation()),(o=this.shadow.getElementById("btn-primary-action"))==null||o.addEventListener("click",()=>{this.inlineEditDraft=null,this.showModal(),this.updateList()}),(r=this.shadow.getElementById("btn-backup"))==null||r.addEventListener("click",async()=>{try{await Wn()}catch(a){console.error("[GP Prompts] Backup failed",a),alert("Backup failed. Please try again.")}}),(i=this.shadow.getElementById("btn-restore"))==null||i.addEventListener("click",()=>{Yn(async a=>{if(alert(a.message),!!a.success){try{await this.sendRuntimeMessage({type:"refreshStateCache"})}catch{}window.location.reload()}})}),this.refreshPickerControls()}sendRuntimeMessage(e){return new Promise((t,o)=>{chrome.runtime.sendMessage(e,r=>{if(chrome.runtime.lastError){o(new Error(chrome.runtime.lastError.message));return}if(r&&r.ok===!1){o(new Error(r.error||"Runtime message failed"));return}t()})})}showModal(e){var c,b,u,f;this.editingPrompt=e||null,this.modalDeleteConfirm=!1,this.modalDeleteTimer&&(window.clearTimeout(this.modalDeleteTimer),this.modalDeleteTimer=null);const t=this.escapeHtml((e==null?void 0:e.title)||""),o=this.escapeHtml((e==null?void 0:e.content)||""),r=this.shadow.getElementById("modal-overlay");r.style.display="flex",r.innerHTML=`
      <div class="modal">
        <div class="modal-header">
          <h2 class="modal-title">${e?"Edit Prompt":"New Prompt"}</h2>
          <button class="modal-close" id="modal-close">${de.close}</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label class="form-label">Name</label>
            <input class="form-input" id="prompt-title" type="text" placeholder="e.g. Code Review" value="${t}" />
          </div>
          <div class="form-group content-group">
            <label class="form-label">Prompt Content</label>
            <div class="textarea-shell">
              <textarea class="form-textarea" id="prompt-content" placeholder="Enter your prompt template...">${o}</textarea>
              <span class="textarea-token" id="content-token-estimate">~0 tokens</span>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <div class="modal-footer-left">
            ${e?'<button class="btn btn-delete" id="modal-delete">Delete</button>':""}
          </div>
          <div class="modal-footer-right">
            <button class="btn btn-cancel" id="modal-cancel">Cancel</button>
            <button class="btn btn-save" id="modal-save">Save</button>
          </div>
        </div>
      </div>
    `;const i=r.querySelector("#prompt-title"),a=r.querySelector("#prompt-content"),s=r.querySelector("#content-token-estimate"),l=r.querySelector("#modal-save"),d=()=>{const h=((a==null?void 0:a.value)||"").length,p=Math.ceil(h/4);s&&(s.textContent=`~${p} tokens`)},g=()=>{const h=((i==null?void 0:i.value)||"").trim(),p=((a==null?void 0:a.value)||"").trim();l&&(l.disabled=!(h.length>0&&p.length>0))};i==null||i.addEventListener("input",()=>{g()}),a==null||a.addEventListener("input",()=>{d(),g()}),d(),g(),(c=r.querySelector("#modal-close"))==null||c.addEventListener("click",()=>this.closeModal()),(b=r.querySelector("#modal-cancel"))==null||b.addEventListener("click",()=>this.closeModal()),(u=r.querySelector("#modal-save"))==null||u.addEventListener("click",()=>this.savePrompt()),(f=r.querySelector("#modal-delete"))==null||f.addEventListener("click",async()=>{const h=r.querySelector("#modal-delete");if(!this.editingPrompt||!h)return;if(!this.modalDeleteConfirm){this.modalDeleteConfirm=!0,h.textContent="Confirm Delete",h.classList.add("confirming"),this.modalDeleteTimer&&window.clearTimeout(this.modalDeleteTimer),this.modalDeleteTimer=window.setTimeout(()=>{this.modalDeleteConfirm=!1,this.modalDeleteTimer=null,h.textContent="Delete",h.classList.remove("confirming")},2200);return}this.modalDeleteTimer&&(window.clearTimeout(this.modalDeleteTimer),this.modalDeleteTimer=null);const p=this.editingPrompt.id;await F.delete(p),this.closeModal(),this.updateList()}),r.onclick=h=>{h.target===r&&this.closeModal()},setTimeout(()=>{i==null||i.focus()},50)}closeModal(){const e=this.shadow.getElementById("modal-overlay");e.style.display="none",e.innerHTML="",this.editingPrompt=null,this.modalDeleteConfirm=!1,this.modalDeleteTimer&&(window.clearTimeout(this.modalDeleteTimer),this.modalDeleteTimer=null)}escapeHtml(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}async savePrompt(){var i,a,s,l,d,g,c;const e=(i=this.shadow.getElementById("prompt-title"))==null?void 0:i.value.trim(),t=(a=this.shadow.getElementById("prompt-content"))==null?void 0:a.value.trim();if(!e||!t){alert("Please fill in Name and Prompt Content.");return}const o=Date.now(),r={id:((s=this.editingPrompt)==null?void 0:s.id)||crypto.randomUUID(),title:e,content:t,tags:[],createdAt:((l=this.editingPrompt)==null?void 0:l.createdAt)||o,updatedAt:o,usageCount:((d=this.editingPrompt)==null?void 0:d.usageCount)||0,lastUsedAt:((g=this.editingPrompt)==null?void 0:g.lastUsedAt)||0,isFavorite:((c=this.editingPrompt)==null?void 0:c.isFavorite)||!1};await F.save(r),this.closeModal(),this.updateList()}startInlineEdit(e){this.inlineEditDraft={id:e.id,title:e.title,content:e.content},this.selectedPromptId=e.id,this.updateList()}cancelInlineEdit(){this.inlineEditDraft=null,this.updateList()}async saveInlineEdit(){const e=this.inlineEditDraft;if(!e)return;const t=e.title.trim(),o=e.content.trim();if(!t||!o){alert("Please fill in both title and content");return}const r=F.get(e.id);if(!r){this.inlineEditDraft=null,this.updateList();return}await F.save({...r,id:r.id,title:t,content:o,tags:[]}),this.inlineEditDraft=null,this.updateList()}refreshPickerControls(){const e=this.shadow.getElementById("btn-primary-action"),t=this.shadow.getElementById("footer-hint"),o=this.shadow.querySelector(".search-input");e&&(e.innerHTML=`${de.plus}<span>New Prompt</span>`,e.title="New Prompt"),t&&(t.style.display="none"),o&&(o.placeholder="Search prompts...")}moveSelection(e){if(!this.visiblePromptIds.length)return;const t=this.selectedPromptId?this.visiblePromptIds.indexOf(this.selectedPromptId):-1,r=((t>=0?t:0)+e+this.visiblePromptIds.length)%this.visiblePromptIds.length;this.selectedPromptId=this.visiblePromptIds[r];const i=this.shadow.getElementById("list-container");i&&i.querySelectorAll(".item").forEach(a=>{const s=a;s.classList.toggle("selected",s.dataset.id===this.selectedPromptId),s.dataset.id===this.selectedPromptId&&s.scrollIntoView({block:"nearest"})})}insertSelectedPrompt(e){if(!this.selectedPromptId)return;const o=F.getAll().find(r=>r.id===this.selectedPromptId);o&&this.onSelect(o,e)}updateList(){const e=this.shadow.getElementById("list-container");if(!e)return;this.refreshPickerControls();const o=F.getAll().filter(i=>i.title.toLowerCase().includes(this.searchQuery)||i.content.toLowerCase().includes(this.searchQuery));e.replaceChildren();const r=o;if(this.visiblePromptIds=r.map(i=>i.id),this.lastVisibleCount=r.length,this.pendingDeletePromptId&&!this.visiblePromptIds.includes(this.pendingDeletePromptId)&&(this.pendingDeletePromptId=null),r.length===0){const i=document.createElement("div");i.className="empty-box",i.textContent="No prompts found",e.appendChild(i),this.selectedPromptId=null,this.applyDynamicHeight(0);return}(!this.selectedPromptId||!this.visiblePromptIds.includes(this.selectedPromptId))&&(this.selectedPromptId=this.visiblePromptIds[0]),r.forEach(i=>{const a=document.createElement("div");a.className="item",a.classList.add("library"),this.selectedPromptId===i.id&&a.classList.add("selected"),a.dataset.id=i.id;const s=this.inlineEditDraft;if(s&&s.id===i.id){a.classList.add("editing");const f=document.createElement("div");f.className="inline-editor";const h=document.createElement("div");h.className="inline-editor-row";const p=document.createElement("label");p.className="inline-editor-label",p.textContent="Title";const x=document.createElement("input");x.className="inline-editor-input",x.type="text",x.value=s.title,x.addEventListener("input",()=>{this.inlineEditDraft&&(this.inlineEditDraft.title=x.value)}),h.appendChild(p),h.appendChild(x);const M=document.createElement("div");M.className="inline-editor-row";const S=document.createElement("label");S.className="inline-editor-label",S.textContent="Content";const A=document.createElement("textarea");A.className="inline-editor-textarea",A.value=s.content,A.addEventListener("input",()=>{this.inlineEditDraft&&(this.inlineEditDraft.content=A.value)}),A.addEventListener("keydown",B=>{(B.ctrlKey||B.metaKey)&&B.key==="Enter"&&(B.preventDefault(),this.saveInlineEdit())}),M.appendChild(S),M.appendChild(A);const H=document.createElement("div");H.className="inline-editor-actions";const R=document.createElement("button");R.className="inline-editor-btn",R.type="button",R.textContent="Cancel",R.addEventListener("click",()=>this.cancelInlineEdit());const D=document.createElement("button");D.className="inline-editor-btn primary",D.type="button",D.textContent="Save",D.addEventListener("click",()=>this.saveInlineEdit()),H.appendChild(R),H.appendChild(D),f.appendChild(h),f.appendChild(M),f.appendChild(H),a.appendChild(f),a.addEventListener("click",B=>B.stopPropagation()),e.appendChild(a),setTimeout(()=>x.focus(),0);return}const l=document.createElement("div");l.className="item-content";const d=document.createElement("div");d.className="item-head";const g=document.createElement("div");g.className="item-title",g.textContent=i.title,d.appendChild(g);const c=document.createElement("div");c.className="item-preview",c.textContent=i.content.replace(/\s+/g," ").trim().slice(0,60),l.appendChild(d),l.appendChild(c),a.appendChild(l);const b=document.createElement("div");b.className="item-actions";const u=document.createElement("button");u.className="item-action-btn",u.dataset.action="edit",u.dataset.id=i.id,u.title="Edit",u.type="button",u.innerHTML=de.edit,u.addEventListener("click",f=>{f.stopPropagation(),this.pendingDeletePromptId=null,this.inlineEditDraft=null,this.showModal(i)}),b.appendChild(u),a.appendChild(b),a.addEventListener("click",f=>{f.target.closest(".item-actions")||(this.pendingDeletePromptId=null,this.selectedPromptId=i.id,this.onSelect(i,!1))}),a.addEventListener("mousemove",()=>{this.selectedPromptId!==i.id&&(this.selectedPromptId=i.id,this.moveSelection(0))}),e.appendChild(a)}),this.applyDynamicHeight(r.length)}async insertPromptContent(e){try{return(await Hn(()=>import("./assets/composer-uSZ6nvjD.js"),[])).insertPrompt(e)===!1?this.insertPromptFallback(e):!0}catch{return this.insertPromptFallback(e)}}insertPromptFallback(e){const t=document.querySelector('rich-textarea [contenteditable="true"], div[contenteditable="true"][role="textbox"], textarea');if(!t)return!1;if(t.focus(),!document.execCommand("insertText",!1,e)){const r=window.getSelection();if(r&&r.rangeCount>0){const i=r.getRangeAt(0);i.deleteContents(),i.insertNode(document.createTextNode(e))}}return t.dispatchEvent(new Event("input",{bubbles:!0})),!0}async onSelect(e,t){if(F.trackUsage(e.id).catch(()=>{}),!!await this.insertPromptContent(e.content)){if(t){this.searchQuery="";const r=this.shadow.querySelector(".search-input");r&&(r.value="",r.focus()),this.updateList();return}this.close()}}};E(K,"instance");let Ne=K;function Xn(){Dn(()=>{const n=document.getElementById("gp-prompt-btn");if(n){const e=n.getBoundingClientRect();Ne.getInstance().toggle(e)}})}function Jn(){const n=document.createElement("style");n.textContent=`
    .gemini-project-folded {
      max-height: 150px;
      overflow: hidden;
      mask-image: linear-gradient(to bottom, black 60%, transparent 100%);
      -webkit-mask-image: linear-gradient(to bottom, black 60%, transparent 100%);
    }
    .gemini-project-relative {
      position: relative !important;
      padding-right: 30px !important; /* Make space for the button */
    }
    .gemini-project-toggle-btn {
      position: absolute;
      top: 8px;
      right: 8px;
      width: 28px;
      height: 28px;
      border-radius: 50%;
      border: 1px solid rgba(0,0,0,0.15);
      background: rgba(255,255,255,0.95);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #333;
      transition: all 0.2s ease;
      z-index: 100;
      box-shadow: 0 2px 6px rgba(0,0,0,0.15);
    }
    .gemini-project-toggle-btn:hover {
      background: #fff;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      transform: scale(1.1);
    }
    
    @media (prefers-color-scheme: dark) {
      .gemini-project-toggle-btn {
        background: rgba(70,70,75,0.95);
        border-color: rgba(255,255,255,0.2);
        color: #fff;
        box-shadow: 0 2px 6px rgba(0,0,0,0.4);
      }
      .gemini-project-toggle-btn:hover {
        background: rgba(90,90,95,1);
        box-shadow: 0 4px 10px rgba(0,0,0,0.5);
      }
    }
  `,document.head.appendChild(n);const e=new MutationObserver(o=>{for(const r of o)r.type==="childList"&&pt()}),t=document.querySelector("main");t?e.observe(t,{childList:!0,subtree:!0}):e.observe(document.body,{childList:!0,subtree:!0}),pt()}function pt(){document.querySelectorAll('[data-message-author-role="user"]').forEach(e=>{if(e.hasAttribute("data-gemini-project-processed"))return;const t=e.querySelector(".whitespace-pre-wrap");if(t&&t.clientHeight>150){e.setAttribute("data-gemini-project-processed","true"),t.classList.add("gemini-project-relative"),t.classList.add("gemini-project-folded");const o=document.createElement("button");o.className="gemini-project-toggle-btn",o.title="Expand",o.innerHTML=gt(),o.onclick=r=>{r.preventDefault(),r.stopPropagation(),t.classList.contains("gemini-project-folded")?(t.classList.remove("gemini-project-folded"),o.innerHTML=eo(),o.title="Collapse"):(t.classList.add("gemini-project-folded"),o.innerHTML=gt(),o.title="Expand")},t.appendChild(o)}})}function gt(){return`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`}function eo(){return`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M18 15L12 9L6 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`}function to(){console.log("[Gemini Projects] Initializing ChatGPT specific features..."),Jn()}const m={projects:[],chatIndex:new Map,expandedProjectIds:new Set,ui:{createModalOpen:!1,contextMenuOpen:!1,pendingMoveConversationId:null},uiPrefs:{projectsCollapsed:!1}};let U=null,j=null,ut=null,Q=null,ve=null,ht=null;function no(...n){}function Se(...n){console.log("[gp-project]",...n)}function ne(n){return new Promise(e=>{chrome.runtime.sendMessage(n,t=>e(t))})}function Tt(n,e){const t=(n||"").trim(),o=((e==null?void 0:e.textContent)||"").trim(),r=`${t} ${o}`.toLowerCase(),i=/(?:\bpinned\b|已置顶|置顶)/i.test(r);return{title:t.replace(/\s*(?:[-–—|·•]?\s*)?(?:pinned)(?:\.{3}|…)?\s*$/i,"").replace(/\s*(?:[-–—|·•]?\s*)?(?:已置顶|置顶)(?:\.{3}|…)?\s*$/i,"").trim()||t,pinnedFromDom:i}}function oo(n){var e;return((e=m.chatIndex.get(n))==null?void 0:e.projectId)??null}function oe(n,e,t){m.projects=n,m.chatIndex=e,m.expandedProjectIds=t,U==null||U.render(m)}function Ee(n){if(!Q)return;Array.from(Q.querySelectorAll("a[href]")).forEach(t=>{const o=t.closest('[role="listitem"], li, div')||t,r=He(o)||q(t.href);if(!r){o.style.display="";return}const i=n.get(r),a=!!(i!=null&&i.projectId);o.style.display=a?"none":""})}async function ro(){if(window.location.hostname.includes("chatgpt.com")||window.location.hostname.includes("openai.com")){to();return}const n=await ne({type:"getState"});n.ok&&n.state&&(m.projects=n.state.projects,m.chatIndex=new Map(Object.entries(n.state.chatIndex)),m.uiPrefs=n.state.uiPrefs||{projectsCollapsed:!1}),io(),so(),Xn()}function io(){const n=()=>{if(j&&document.contains(j)){Oe();return}j=mt(),j&&(Oe(),ao())};new MutationObserver(()=>n()).observe(document.body,{childList:!0,subtree:!0}),n()}function ao(){if(!j)return;new MutationObserver(()=>{Oe(),At()}).observe(j,{childList:!0,subtree:!0})}function Oe(){if(!j)return;const n=Dt(j),e=bt(j);if(!n||!e)return;const{shadow:t,overlayShadow:o}=Ot(j,n,e);U||(U=cn({shadow:t,overlayShadow:o,onSaveProject:lo,onToggleProjectExpand:co,onDeleteProject:go,onToggleCollapse:po,onRemoveChatFromProject:uo,onMoveChatToProject:ho})),oe(m.projects,m.chatIndex,m.expandedProjectIds),ht||(ht=Wt({overlayShadow:o,getProjects:()=>m.projects,getChatProjectId:oo,onMoveChat:_e,onCreateProject:()=>U==null?void 0:U.openCreateModal()})),At()}function At(){if(!j)return;const n=bt(j);if(!n)return;ut=n;const e=$t(ut);e&&(Q!==e&&(Q=e,ve&&ve.disconnect(),ve=new MutationObserver(()=>{ft(),Ee(m.chatIndex),oe(m.projects,m.chatIndex,m.expandedProjectIds)}),ve.observe(Q,{childList:!0,subtree:!0})),ft(),Ee(m.chatIndex))}function so(){document.addEventListener("click",n=>{const e=n.target;if(!e)return;const t=e.closest("a[href]");if(!t)return;const o=q(t.href);if(!o)return;const r=m.chatIndex.get(o),i=t.closest('[role="listitem"], li, div')||t,a=Tt((t.textContent||"").trim()||(r==null?void 0:r.title)||"",i),s=a.title||(r==null?void 0:r.title)||"";m.chatIndex.set(o,{conversationId:o,title:s,isPinned:a.pinnedFromDom?!0:(r==null?void 0:r.isPinned)??!1,projectId:(r==null?void 0:r.projectId)??null,updatedAt:Date.now(),lastUrl:t.href}),ne({type:"upsertChatRefs",chats:[{conversationId:o,title:s,isPinned:a.pinnedFromDom?!0:(r==null?void 0:r.isPinned)??!1,projectId:(r==null?void 0:r.projectId)??null,updatedAt:Date.now(),lastUrl:t.href}]}).catch(()=>{})})}function ft(){if(!Q)return;const n=Array.from(Q.querySelectorAll("a[href]")),e=[];n.forEach(t=>{var s,l;const o=t.closest('[role="listitem"], li, div')||t,r=He(o)||q(t.href);if(!r)return;const i=Tt((t.textContent||"").trim(),o),a=i.title;a&&e.push({conversationId:r,title:a,isPinned:i.pinnedFromDom?!0:((s=m.chatIndex.get(r))==null?void 0:s.isPinned)??!1,updatedAt:Date.now(),projectId:((l=m.chatIndex.get(r))==null?void 0:l.projectId)??null,lastUrl:t.href})}),e.length&&(e.forEach(t=>{const o=m.chatIndex.get(t.conversationId);m.chatIndex.set(t.conversationId,{...t,projectId:(o==null?void 0:o.projectId)??t.projectId,isPinned:typeof t.isPinned=="boolean"?t.isPinned:(o==null?void 0:o.isPinned)??!1})}),ne({type:"upsertChatRefs",chats:e}).catch(()=>{}))}async function lo(n){const e=await ne({type:"upsertProject",project:n});e.ok&&e.state&&(m.projects=e.state.projects,oe(m.projects,m.chatIndex,m.expandedProjectIds))}function co(n){if(m.expandedProjectIds.has(n))m.expandedProjectIds.delete(n);else{m.expandedProjectIds.add(n);const e=Array.from(m.chatIndex.values()).filter(t=>t.projectId===n).length;Se("expand projectId=",n,"items=",e)}oe(m.projects,m.chatIndex,m.expandedProjectIds)}function po(n){m.uiPrefs.projectsCollapsed=n,ne({type:"updateUiPrefs",prefs:{projectsCollapsed:n}}),oe(m.projects,m.chatIndex,m.expandedProjectIds)}async function go(n){const e=await ne({type:"deleteProject",projectId:n});e.ok&&e.state&&(m.projects=e.state.projects,m.chatIndex=new Map(Object.entries(e.state.chatIndex)),m.expandedProjectIds.delete(n),oe(m.projects,m.chatIndex,m.expandedProjectIds),Ee(m.chatIndex))}async function _e(n,e){Se("moveChat conversationId=",n,"to projectId=",e);const t=await ne({type:"moveChat",conversationId:n,projectId:e});t.ok&&t.state&&(m.chatIndex=new Map(Object.entries(t.state.chatIndex)),oe(m.projects,m.chatIndex,m.expandedProjectIds),Ee(m.chatIndex))}async function uo(n){Se("removeChatFromProject conversationId=",n),await _e(n,null)}async function ho(n,e){Se("moveChatToProject conversationId=",n,"to projectId=",e),await _e(n,e)}ro().catch(n=>no("bootstrap failed",n));
//# sourceMappingURL=content.js.map
